                  <div class="clearfix"></div> 
				  <footer>
                      <div class="footer">
                          <div class="container" <?php if(!is_front_page()) {?>class="top45"<?php } ?>>
                              <div class="row">                                  
                                  <div class="col-sm-4 col-md-4 redes">
                                          <div class="social-icons">
                                              <span>
                                                  <a href="https://pt-br.facebook.com/harasrosamystica/" target="_blank" title="Facebook Fan Page"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-facebook.png" alt="Facebook Fan Page" /></a>
                                              </span>
                                              <span>
                                                  <a href="https://www.instagram.com/harasrosamystica" target="_blank" title="Instagram"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-instagram.png"  alt="Instagram" /></a>
                                              </span>
											  <p class="hidden-xs"> /harasrosamystica</p>
                                          </div>
                                      
                                  </div>      
                                  <div class="hidden-xs col-sm-4 col-md-4 copyright">
										<p>Copyright &copy; Haras Rosa Mystica</p>
                                  </div>
                                  <div class="col-sm-4 col-md-4 developed">
                                      <p><a href="http://www.input.com.vc" target="_blank" title="desenvovido por by Input Tecnologia"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-input.png" width="74" height="61" alt="Input Tecnologia" /></a></p>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </footer>
              </div><!-- /#shadow -->
          </div><!-- /#page -->
      </div><!-- /#body -->
  

</div>
<script>
      var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-9755924-10']);
      _gaq.push(['_trackPageview']);

      (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
      })();
</script>

<?php wp_footer(); ?>	
</body>
</html>
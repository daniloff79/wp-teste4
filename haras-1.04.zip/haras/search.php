<?php get_header(); ?>
				  
<section>
                      
    <div id="container">
        <div class="container article">
			
				<?php if(have_posts()) : ?>
				
				<p class="resultado">A busca retornou <?php global $wp_query; echo $wp_query->found_posts; ?> resultado(s) para <b><?php echo get_search_query(); ?></b>, veja abaixo:</p>

				<div class="row row1">
				<?php while ( have_posts() ) : the_post(); ?>
					<div class="col-md-12 col-lg-10 col-lg-push-1 resultado-box">
						<a href="<?php the_permalink(); ?>" class="title-link"><?php the_title( '<h1 class="page-header">', '</h1>' ); ?></a>
						<?php if ( get_post_meta( $post->ID, 'wpcf-pai', true ) ) { ?>
						<p class="filiacao">
							<?php $meta1 = get_post_meta( $post->ID, 'wpcf-pai', true ); 
							echo $meta1; ?> x <?php $meta2 = get_post_meta( $post->ID, 'wpcf-avo-materno', true ); 
							echo $meta2; ?>
						</p>
						<?php }
						if ( has_post_thumbnail() ) { ?>
						<div class="resultado-resumo">
							<?php the_excerpt(); ?>
						</div>
						<div class="resultado-img">
							<?php the_post_thumbnail('medium', array('class' => 'img-responsive')); ?>
						</div>
						<?php } else {
							the_excerpt();				
						} ?>
					</div>
				<?php endwhile; ?>
				</div>
				
				<?php else : ?>
				<div class="row">
					<div class="col-md-12 col-lg-10 col-lg-push-1 resultado-container">
					<?php if(isset($_GET['s']) && $_GET['s']!='') { ?>
					<p class="resultado">A busca n�o encontrou nada para <b><?php echo get_search_query(); ?></b>. Tente com outros termos:</p>
					<?php } else { ?>
					<p class="resultado">Conte�do n�o encontrado. Tente usar a busca:</p>
					<?php } ?>
					<form role="search" method="get" class="input-group" action="<?php echo site_url(); ?>">
						<input type="search" class="form-control" id="search2" placeholder="Busca" aria-describedby="search" value="" name="s">
						<span class="input-group-btn">
						<button class="btn btn-default" type="submit" id="search-button2"><span class="glyphicon glyphicon-search"></span></button>
						</span>
					</form>
					<p class="resultado"><a href="#" onclick="window.history.back()" class="amarelo-queimado">Clique aqui para voltar</a></p>
					</div>
				</div>
				<?php endif; ?>
			
        </div><!-- /.container article -->
    </div>

    </section>
<?php get_footer(); ?>
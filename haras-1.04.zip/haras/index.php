<?php get_header(); ?>
				  
<section>
                      
    <div id="container">
        <div class="container article">
			
				<?php if(have_posts()) : ?>
				
				<div class="row">
					<div class="col-sm-12">
						<ol class="breadcrumb">
							<li><a href="/">Home</a></li>
							<?php the_title( '<li class="active">', '</li> ' ); ?>
						</ol>
					</div>
				</div>

				<div class="row row1">
				<?php while ( have_posts() ) : the_post(); ?>
					<div class="col-md-12">
					
					<?php 
					the_title( '<h1 class="page-header">', '</h1>' ); 
					the_content();
					?>
						
					</div>
				<?php endwhile; ?>
				</div>
				
				<?php else : ?>
				<div class="row">
					<br />
					<div class="col-sm-12" style="background: white; min-height: 200px">
					<h2>P&aacute;gina n&atilde;o encontrada</h2>
					<?php $classes = get_body_class();
					if (in_array('error404',$classes)) { 
						if (strpos($_SERVER['REQUEST_URI'],'home/Default') !== false) { 
							header('Location:  http://www.harasrosamystica.com.br',TRUE,301);
							?><p>Redirecionando</p>
							<script>window.location = "http://www.harasrosamystica.com.br";</script>
							<?php
						}  elseif (strpos($_SERVER['REQUEST_URI'],'artigos/o_haras') !== false) {
							header('Location:  http://www.harasrosamystica.com.br/sobre',TRUE,301);
							?><p>Redirecionando</p>
							<script>window.location = "http://www.harasrosamystica.com.br/sobre";</script>
							<?php
						}  elseif (strpos($_SERVER['REQUEST_URI'],'links/cavalo') !== false) {
							header('Location:  http://www.harasrosamystica.com.br/',TRUE,301);
							?><p>Redirecionando</p>
							<script>window.location = "http://www.harasrosamystica.com.br/";</script>
							<?php 
						}  elseif (strpos($_SERVER['REQUEST_URI'],'links/contato') !== false) {
							header('Location:  http://www.harasrosamystica.com.br/contato-sobre-cavalos',TRUE,301);
							?><p>Redirecionando</p>
							<script>window.location = "http://www.harasrosamystica.com.br/contato-sobre-cavalos";</script>
							<?php 
						}  elseif (strpos($_SERVER['REQUEST_URI'],'leilao2017') !== false) {
							header('Location:  https://prodweb.input.com.vc:347/2017/leilao2017/',TRUE,301);
							?><p>Redirecionando</p>
							<script>window.location = "https://prodweb.input.com.vc:347/2017/leilao2017/";</script>							
							<?php } else { header('Location: http://www.harasrosamystica.com.br/?s'); }
					} ?>
					</div>
				</div>
				<?php endif; ?>
			
        </div><!-- /.container article -->
		<?php  if (is_page( 16 )) {
			$selecao = array ( $_SERVER['QUERY_STRING'] );
			if (!empty($selecao[0])) {
				$espaco = str_replace('%20', ' ', $selecao[0]);
				$traco = str_replace('-', ' ', $espaco); ?>
				<script>
					jQuery("#field_fxswx").val("Gostaria de mais informa��es sobre o cavalo <?php echo ucwords($traco); ?>")
				</script>
		<?php } } ?>
    </div>

    </section>
<?php get_footer(); ?>
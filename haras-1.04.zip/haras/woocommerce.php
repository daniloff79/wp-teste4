<?php get_header(); ?>
				  
<section>
                      
    <div id="container">
        <div class="container article">
				
				<div class="row">
					<div class="col-sm-12">
						<ol class="breadcrumb">
							<li><a href="/">Home</a></li>
							<li><a href="/loja/">Loja virtual</a></li>
							<?php the_title( '<li class="active">', '</li> ' ); ?>
						</ol>
					</div>
				</div>

				<div class="row row1">
					<div class="col-sm-12">				
				<?php woocommerce_content(); ?>				
					</div>
				</div>
				
		
        </div><!-- /.container article -->
    </div>

    </section>
<?php get_footer(); ?>
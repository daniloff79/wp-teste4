<?php get_header(); ?>
				  
<section>
                      
    <div id="container">
        <div class="container article">
				
				<div class="row">
				<?php $classes = get_body_class(); 
				if (in_array('logged-in',$classes)) { ?>
					<div class="col-md-10">
				<?php } else { ?>
					<div class="col-md-12">
				<?php } ?>
						<ol class="breadcrumb">
							<li><a href="/">Home</a></li>
							<li><a href="/loja/">Loja virtual</a></li>
							<?php the_title( '<li class="active">', '</li> ' ); ?>
						</ol>
					</div>
							<?php
							if (in_array('logged-in',$classes)) { ?>
					<div class="col-md-2">
						<div class="cartcrumb">
							<a href="<?php echo site_url(); ?>/carrinho/"><span class="glyphicon glyphicon-shopping-cart"></span> Ir para o carrinho</a>
						</div>
					</div>
					<?php } ?>
				</div>

				<div class="row row1">
					<div class="col-md-12">				
				<?php woocommerce_content(); ?>				
					</div>
				</div>
				
		
        </div><!-- /.container article -->
    </div>

    </section>
<?php get_footer(); ?>
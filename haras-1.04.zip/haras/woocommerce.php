<?php get_header(); ?>
				  
<section>
                      
    <div id="container">
        <div class="container article">
				
				<div class="row">
					<div class="col-sm-12">
						<ol class="breadcrumb">
							<li><a href="/">Home</a></li>
							<li><a href="/loja/">Loja virtual</a></li>
							<?php the_title( '<li class="active">', '</li> ' ); ?>
						</ol>
					</div>
				</div>

				<div class="row row1">
					<div class="col-sm-12">				
				<?php woocommerce_content(); ?>				
					</div>
				</div>
				
		
        </div><!-- /.container article -->
		<?php  if (is_page( 16 )) {
			$selecao = array ( $_SERVER['QUERY_STRING'] );
			if (!empty($selecao[0])) {
				$espaco = str_replace('%20', ' ', $selecao[0]);
				$traco = str_replace('-', ' ', $espaco); ?>
				<script>
					jQuery("#field_fxswx").val("Gostaria de mais informações sobre o cavalo <?php echo ucwords($traco); ?>")
				</script>
		<?php } } ?>
    </div>

    </section>
<?php get_footer(); ?>
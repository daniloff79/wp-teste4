function um() {
	jQuery( ".lista-lotes .cavalo" ).each(function() { jQuery( this ).hide(); });
	jQuery( ".lista-lotes .salto" ).each(function() { jQuery( this ).show(); });
	jQuery( ".menu-lotes li" ).each(function() { jQuery( this ).removeClass("active"); });
	jQuery( "#salto-li" ).addClass("active");
}

function dois() {
	jQuery( ".lista-lotes .cavalo" ).each(function() { jQuery( this ).hide(); });
	jQuery( ".lista-lotes .dressage" ).each(function() { jQuery( this ).show(); });
	jQuery( ".menu-lotes li" ).each(function() { jQuery( this ).removeClass("active"); });
	jQuery( "#dressage-li" ).addClass("active");
	jQuery('.lista-lotes a').each(function() {
		var href = jQuery(this).attr('href');
		if (href) {
			href = href.split("#");
			newhref = href[0] + '#2';
			jQuery(this).attr('href', newhref);
		}
	});	
}

function tres() {
	jQuery( ".lista-lotes .cavalo" ).each(function() { jQuery( this ).hide(); });
	jQuery( ".lista-lotes .a-venda" ).each(function() { jQuery( this ).show(); });
	jQuery( ".menu-lotes li" ).each(function() { jQuery( this ).removeClass("active"); });
	jQuery( "#a-venda-li" ).addClass("active");
	jQuery('.lista-lotes a').each(function() {
		var href = jQuery(this).attr('href');
		if (href) {
			href = href.split("#");	
			newhref = href[0] + '#3';
			jQuery(this).attr('href', newhref);
		}
	});
}
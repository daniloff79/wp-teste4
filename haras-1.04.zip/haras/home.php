<?php get_header(); ?>
				  
<section>
                      
    <div id="container">
	
        <div class="container article">
			<?php 
			$paged = 1;
			if ( get_query_var('paged') ) $paged = get_query_var('paged');
			if ( get_query_var('page') ) $paged = get_query_var('page');
			$args = array(
				'post_type' => 'post',
				'posts_per_page' => '5', 
				'paged' => $paged,
			);
			$wp_query = new WP_Query( $args );
				
			if ( have_posts() ) : ?>

			<div class="row">
				<div class="col-sm-12">
					<ol class="breadcrumb">
						<li><a href="/" id="homelink">Home</a></li>
						<li class="active">Not�cias</li>
					</ol>
				</div>
				<div class="col-sm-12">
					<h2 class="page-header">Not�cias</h2>
				</div>
			</div>
			
			<div class="row row1">			
				<?php $count = 0;
					while ( have_posts() ) : the_post();
					$count++;
					?>
					<div class="col-sm-7 col-md-8 resultado-box resultado<?php echo $count; ?>">
						<a href="<?php the_permalink(); ?>" class="title-link"><?php the_title( '<h1 class="page-header">', '</h1>' ); ?></a>
						
						<?php if ( has_post_thumbnail() ) { ?>
						<div class="resultado-resumo">
							<?php the_excerpt(); ?>
						</div>
						<div class="resultado-img">
							<?php the_post_thumbnail('medium', array('class' => 'img-responsive')); ?>
						</div>
						<?php } else {
							the_excerpt();				
						} ?>
					</div>
				<?php if ($count < 2) { ?>
					<aside class="col-sm-5 col-md-4">
						<div class="well">
							<p>Busque uma not�cia</p>
							<form role="search" method="get" class="input-group" action="<?php echo site_url(); ?>">
								<input type="search" class="form-control" id="search2" placeholder="Digite uma palavra-chave" aria-describedby="search" value="" name="s">
									<span class="input-group-btn">
									<input type="hidden" name="post_type" value="post" /> 
									<button class="btn btn-default" id="search-button2" type="submit"><span class="glyphicon glyphicon-search"></span></button>
								</span>
							</form>
						</div>
					</aside>
				<?php } else { ?>
				<div class="col-sm-5 col-md-4">
				</div>
				<?php } 
				endwhile; 
				?>
				<div class="col-md-8 pagination-container">
					<?php
						// pagination 
						the_posts_pagination( array(
						'base' => '/noticias/%#%',
						'screen_reader_text' => ' ',
						'title' => ' ',
						'type' => 'list',
						'prev_text' => '&laquo;',
						'next_text' => '&raquo;',
						'separator' => '&verbar;',
						'mid_size'  => 3, )
						);
					?>
				</div>
			</div>
			
			<?php else : ?>
			<div class="row">
				<br />
				<div class="col-md-5">
				<h2>Nenhuma not�cia encontrada</h2>
				</div>
			</div>
			
			<?php endif; ?>
        </div><!-- /.container article -->
		
    </div>

</section>

<?php get_footer(); ?>
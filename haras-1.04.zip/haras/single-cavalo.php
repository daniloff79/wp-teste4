<?php get_header(); ?>
				  
<section>
                      
    <div id="container">
        <div class="container article">

				<?php if(have_posts()) : the_post(); ?>

				<div class="row">
					<div class="col-sm-12">
						<ol class="breadcrumb">
							<li><a href="/" id="homelink">Home</a></li>
							<?php if(has_category( 'a-venda' )) {
								the_title( '<li class="active">', ' Mystic Rose</li>' );
							} else { 
								the_title( '<li class="active">', '</li>' );
							} ?>
						</ol>
					</div>
				</div>
				
				<script>
				jQuery( document ).ready(function() {
					if(window.location.hash) { 
						var hash = window.location.hash.substring(1);
						var hrefsup = jQuery('#item-01 a').attr('href');
						var href = jQuery('#homelink').attr('href');
						if (hash == '2') {
							newhrefsup = hrefsup + '#2'; newhref = href + '#2';
							jQuery('#item-01 a').attr('href', newhref); jQuery('#homelink').attr('href', newhref);
						}
						if (hash == '3') {
							newhrefsup = hrefsup + '#3'; newhref = href + '#3';
							jQuery('#item-01 a').attr('href', newhref); jQuery('#homelink').attr('href', newhref);
						}
					}
					if(jQuery('.row2 .col-sm-5 .embed-responsive').find('img.wp-post-image').length !== 0) {
						jQuery('.row2 .col-sm-5 .embed-responsive-16by9').css('padding-bottom','77%');
					}
				});
				</script>
				   
				<div class="row row1">
					<div class="col-sm-12"> 
					    <?php if(has_category( 'a-venda' )) {
							the_title( '<h1 class="page-header">', ' Mystic Rose</h1>' );
						} else { 
							the_title( '<h1 class="page-header">', '</h1>' );
						} ?>
					</div>
				</div>
			    <div class="row row2">
					<div class="col-sm-7">
						<p class="filiacao">
							<?php $meta1 = get_post_meta( $post->ID, 'wpcf-pai', true ); 
							echo $meta1; ?> x <?php $meta2 = get_post_meta( $post->ID, 'wpcf-avo-materno', true ); 
							echo $meta2; ?>
						</p>
						<p class="info-basica"> 
							<?php $meta3 = get_post_meta( $post->ID, 'wpcf-sexo-do-animal', true ); 
							echo ucfirst($meta3); // sexo ?> 
							<br />Cor <?php $meta4 = get_post_meta( $post->ID, 'wpcf-cor-da-pelagem', true ); 
							echo ucfirst($meta4); // cor ?> 
							<br />Nascido em <?php $meta5 = get_post_meta( $post->ID, 'wpcf-data-de-nascimento', true ); 
							echo date("d/m/Y", $meta5); // nascimento ?>

						   <!-- <div id="biometria">
							
						   </div> -->
						   
						</p>
						<hr class="areia">
						<div class="description">
							<?php the_content(); ?>
						</div>
						<div class="bar">
							<a href="/contato-sobre-cavalos/?<?php the_title(); ?>" class="btn btn-default btn-sm" type="button"><span class="glyphicon glyphicon-envelope"></span> Contato</a>
						</div>
					</div>
					<div class="col-sm-5">
						<?php if(!has_category( 'a-venda' )) { ?>
						<div class="embed-responsive embed-responsive-16by9">
						<?php } else { ?>
						<div class="midia">
						<?php } ?>
							<?php $meta6 = get_post_meta( $post->ID, 'wpcf-midia', true ); 
							if(empty($meta6)) { 
								the_post_thumbnail('medium', array('class' => 'img-responsive'));
							} else { echo $meta6; }
							?>
						</div>
					</div>
				</div>	<!-- /row2 -->		
				
				<?php $meta7 = get_post_meta( $post->ID, 'wpcf-midia-secundaria', true ); 
					if(!empty($meta7)) { ?> 				
				<div class="row row3">
					<div class="col-sm-12 heading">
						<h2>Fotos</h2>
					</div>
					
					<?php echo $meta7; // fotos ?> 

				</div>
				<?php } ?>

				<div class="row genealogia-article">
					<div class="col-sm-12 heading">
						<h2>Genealogia</h2>
					</div>
					<?php $arvore = get_post_meta( $post->ID, 'wpcf-arvore-genealogica', true ); 
							echo $arvore; // arvore-genealogica ?> 
				</div>
				
				
					<?php
					$cavalo_slug = $post->post_name; 
					$cavalo_ID = get_the_ID(); // tag ou id para biometria 
					//wp_reset_query();
					
					$biometria = new WP_Query( array('post_type' => 'biometria', 'tag' => $cavalo_slug) );
					if ( $biometria->have_posts() ) : $biometria->the_post(); 
						
						$data = get_post_meta( $post->ID, 'wpcf-data', true ); 
						$dataformatada = date_i18n("F/Y", $data);							
						$meta1 = get_post_meta( $post->ID, 'wpcf-altura', true );  
						
						if (empty($data)) { ?>
							<!-- <script>
							jQuery('#biometria').remove();
							</script>	 -->
						<?php } else { ?>
							<!-- <script>
							jQuery('#biometria').html('Altura em <?php echo $dataformatada; ?>: <?php echo $meta1; ?> cm');
							</script> -->
						<?php } 
					    endif;
				
				else : ?>
				<div class="row">
					<br />
					<div class="col-sm-12" style="background: white; min-height: 200px">
					<h2>Cavalo n&atilde;o encontrado</h2>
					</div>
				</div>
				<?php endif; ?>
        </div><!-- /.container article -->
    </div>

    </section>
<?php get_footer(); ?>
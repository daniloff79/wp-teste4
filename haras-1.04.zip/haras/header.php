<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta name="google-site-verification" content="BPMD-vn4XBZrJsROnl7kaN1kUPV5Sh6SE8somX3dWw8" />
<?php if (is_front_page() || is_page(2)) { ?>
	<title>Haras Rosa Mystica</title>
<? } elseif (is_search()) { ?>
	<title><?php printf(__ ("Resultados da busca por '%s'", ""),  attribute_escape(get_search_query())); ?> </title>
<?php } else { ?>
	<title><?php wp_title('', true,''); ?> | Haras Rosa Mystica</title>
<?php } ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="initial-scale=1, maximum-scale=1" />

<meta property="og:url" content="<?php echo site_url(); ?>" />
<meta property="og:title" content="Haras Rosa Mystica" />

<link rel="icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon.ico">	
<?php wp_head(); ?>
</head>

<body <?php if(!is_search()) { body_class(isset($class) ? $class : ''); } else { ?>class="search search-results"<?php } ?>>
  <div id="aspnetForm">
      
      <div id="body">
          <div id="page">
              <div id="shadow">
                  <header id="header">
                      <div class="body-header">
                          <div class="top-row">
                              <div class="container-fluid">
                                  <nav class="navbar navbar-default" role="navigation">
                                      <div class="navbar-header">								  
                                         <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-1" aria-expanded="false">
                                              <span class="sr-only">Toggle navigation</span>
                                              <span class="icon-bar"></span>
                                              <span class="icon-bar"></span>
                                              <span class="icon-bar"></span>
                                          </button>
										  
                                          <div class="navbar-brand">
                                            <a href="/">
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/logoHRM.png" class="img" alt="Haras Rosa Mystica" /><h1>Haras Rosa Mystica</h1>
                                            </a>
                                          </div>
                                      </div>
                                     <div class="collapse navbar-collapse" id="navbar-collapse-1">

											<?php wp_nav_menu( array('menu' => 'Menu principal', 'menu_class' => 'nav navbar-nav',  'container'=> false)); ?>
														
											  <li class="visible-xs-block">
											  <form role="search" method="get" class="col-xs-12 input-group" action="<?php echo site_url(); ?>">
													<input type="search" class="form-control" id="search3" placeholder="Busca" aria-describedby="search" value="" name="s">
													<span class="input-group-btn">
														<button class="btn btn-default" type="submit" id="search-button3"><span class="glyphicon glyphicon-search"></span></button>
													</span>
													<script>
													  function key_down(e) {
														if(e.keyCode === 13) {
														if(jQuery("#search").is(":focus")) { jQuery("#search-button3").trigger("click"); }
														}
													  }
													</script>
											</form>

                                      </div>
                                  </nav>
									<div class="container">
										<div class="row hidden-xs ">
											<div class="col-sm-4 col-sm-offset-8 col-md-3 col-sm-offset-8 col-md-offset-9">
											  <form role="search" method="get" class="input-group" action="<?php echo site_url(); ?>">
													<input type="search" class="form-control" id="search" placeholder="Busca" aria-describedby="search" value="" name="s">
													<span class="input-group-btn">
														<button class="btn btn-default" type="submit" id="search-button"><span class="glyphicon glyphicon-search"></span></button>
													</span>
													<script>
													  function key_down(e) {
														if(e.keyCode === 13) {
														if(jQuery("#search").is(":focus")) { jQuery("#search-button").trigger("click"); }
														}
													  }
													</script>
											</form>
											</div>
											<a href="http://www.schockemoehle.com/" target="_new"><img src="<?php echo get_template_directory_uri(); ?>/img/faixa.png" id="faixa" class="img" alt="representante oficial no Brasil de Paul Schockem�hle"></a>
											<a href="http://brasileirodehipismo.com.br" target="_new"><img src="<?php echo get_template_directory_uri(); ?>/img/selo.png" id="selo" class="img" alt="associa��o brasileira dos criadores de cavalo de hipismo"></a>
										</div>
									</div>
                              </div>
                          </div>
                      </div>
                  </header>

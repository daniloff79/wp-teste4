<?php
/* 
Theme Name: Haras
Theme URI: http://www.input.com.br
*/

// adicionar thumbnails, remover vers�o, remover emojis
add_theme_support( 'post-thumbnails' );
remove_action( 'wp_head', 'wp_generator' );	
remove_action( 'wp_head', 'print_emoji_detection_script', 7);
remove_action( 'wp_print_styles', 'print_emoji_styles');
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );

// largura padr�o
if ( ! isset( $content_width ) ) {
	$content_width = 1200;
}

function theme_enqueue() {
	wp_enqueue_script( 'bootstrap-script', get_template_directory_uri() . '/library/bootstrap.min.js', array( 'jquery' ), null, true );
	if (is_front_page()) {
		wp_enqueue_script( 'front-page', get_template_directory_uri() . '/library/frontp.js' );
		wp_deregister_script( 'formidable' );  // retira js n�o usado na home
	}
	wp_enqueue_style( 'bootstrap-style', get_template_directory_uri() . '/library/bootstrap.min.css' );
	wp_enqueue_style( 'main-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'theme_enqueue', 1 );

// retira css de plugin onde n�o � usado
function economic() {
	if (is_front_page() || is_page(2) || is_search()) { 
		wp_dequeue_style( 'responsive-lightbox-nivo_lightbox-css' );
		wp_deregister_style( 'responsive-lightbox-nivo_lightbox-css' );
		wp_dequeue_style( 'responsive-lightbox-nivo_lightbox-css-d' );
		wp_deregister_style( 'responsive-lightbox-nivo_lightbox-css-d' );
		wp_dequeue_style( 'formidable' );
		wp_deregister_style( 'formidable' );
		wp_dequeue_style( 'frm_fonts' );
		wp_deregister_style( 'frm_fonts' );
	}
	if (is_page(16)) { 
		wp_dequeue_style( 'responsive-lightbox-nivo_lightbox-css' );
		wp_deregister_style( 'responsive-lightbox-nivo_lightbox-css' );
		wp_dequeue_style( 'responsive-lightbox-nivo_lightbox-css-d' );
		wp_deregister_style( 'responsive-lightbox-nivo_lightbox-css-d' );	
	}
}
add_action( 'wp_print_styles', 'economic', 11 );
add_action( 'wp_head', 'economic', 8 );

// slug na classe do body
function add_slug_body_class( $classes ) {
	global $post;
	if ( isset($post) && !is_post_type_archive() )  {
		$classes[] = $post->post_type . '-' . $post->post_name;
	}
	return $classes;
}
add_filter( 'body_class', 'add_slug_body_class' );

// css do editor
add_editor_style( 'library/style-editor.css' );

// adiciona excerpt nas p�ginas
function wpcodex_add_excerpt_support_for_pages() {
	add_post_type_support( 'page', 'excerpt' );
}
add_action( 'init', 'wpcodex_add_excerpt_support_for_pages' );

// lista de tags/cavalos poss�veis.
function cavalo_certo() { ?>
   <script type="text/javascript">
		jQuery( "body.post-type-biometria #tagsdiv-post_tag h2 span" ).html("Cavalo");
		jQuery( "body.post-type-post #tagsdiv-post_tag" ).hide();	
		jQuery( "body.post-type-cavalo #tagsdiv-post_tag" ).hide();	
    </script>
    <?php
}
add_action( 'admin_footer-post.php',     'cavalo_certo' );
add_action( 'admin_footer-post-new.php', 'cavalo_certo' );

// avisa sobre tags
function tag_cavalo() { 
	echo '<style>';
    echo 'body.edit-tags-php h1.wp-heading-inline:after {content: "/cavalos";}';
    echo '</style>';
}
add_action( 'admin_head', 'tag_cavalo' );

// remove tag da lista de biometrias
function remove_submenu() {
    remove_submenu_page( 'edit.php?post_type=biometria', 'edit-tags.php?taxonomy=post_tag&amp;post_type=biometria' );
}
add_action( 'admin_menu', 'remove_submenu', 999 );

// limita hist�rico
define( 'WP_POST_REVISIONS', 10 );

// login com logo do site
function login_logo() { ?>
    <style type="text/css">
		#login { 
			padding: 2% 0 0 !important;
		}
        #login h1 a, .login h1 a {
            background-image: url('<?php echo get_template_directory_uri(); ?>/img/logo-pb.png');
			width: 320px;
			background-size: 100px 83px;
			background-repeat: no-repeat;
			background-position: center;
        	padding-bottom: 30px;
			margin-top: 20px;
        }
		#loginform::after {
			content: "Criado pela Input Tecnologia";
			display: block;
			position: relative;
			clear: both;
			color: #72777c;		
			margin-top: 60px;
			height: 30px;
			margin-bottom: -30px;		
		}
    </style>
<?php }
add_action( 'login_enqueue_scripts', 'login_logo' );

// leia mais ap�s excerpt
function new_excerpt_more($more) {
       global $post;
	return '... <a class="more" href="'. get_permalink($post->ID) . '">leia mais</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');

// p�gina de manuten��o customizada
function wp_maintenance_mode(){
    if(!current_user_can('edit_themes') || !is_user_logged_in()){
	    if( file_exists( ABSPATH . '.maintenance' ) ) {
            wp_die('
			<img src="http://www.harasrosamystica.com.br/wp-content/themes/haras/img/logo-pb.png" alt="Haras Rosa Mystica">
			<br />
			<div style="display:block;font-family: Calibri,Arial,Helvetica,sans-serif; font-size: 14px;line-height: 1.42em;margin-top:20px">
			<h1 style="color:#a2112a;font-weight: 700;border:none">Site em manuten��o ou atualiza��o</h1>
			<br />
			<p>Volte mais tarde.</p>
			</div>
			');
        }
    }
}
add_action('get_header', 'wp_maintenance_mode');

// menu principal
function register_menu() {
  register_nav_menu('header-menu',__( 'Menu principal' ));
}
add_action( 'init', 'register_menu' );

// woocommerce
add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

?>
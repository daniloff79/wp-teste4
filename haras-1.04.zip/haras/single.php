<?php get_header(); ?>
				  
<section>
                      
    <div id="container">
        <div class="container article">
			
				<?php if(have_posts()) : ?>
				
				<div class="row">
					<div class="col-sm-12">
						<ol class="breadcrumb">
							<li><a href="/">Home</a></li>
							<li><a href="/noticias/">Not�cias</a></li>
							<?php the_title( '<li class="active">', '</li> ' ); ?>
						</ol>
					</div>
				</div>

				<div class="row row1">
				<?php while ( have_posts() ) : the_post(); ?>
					
					<div class="col-md-12 col-lg-10 col-lg-push-1">
					<?php the_title( '<h1 class="page-header">', '</h1>' ); ?>
					<?php date_i18n( 'j \d\e F \d\e Y', the_date( 'j \d\e F \d\e Y', '<h4 class="entry-date">', '</h4>' ) ); ?>
					</div>
					
					<div class="col-md-12 col-lg-10 col-lg-push-1 entry-content">
					<?php the_content(); ?>	
					<div class="clearfix"></div>
					<hr class="areia">
					</div>
					
					<div class="clearfix"></div>
					<div class="entry-footer col-md-3 col-lg-2 col-lg-push-1">
						<a href="javascript:window.print()"><img src="<?php echo get_template_directory_uri(); ?>/img/btn-print.png" alt="imprimir" id="btn-print"></a> 
						<a href="javascript:window.print()" id="txt-print">imprimir</a>
					</div>
					
					<div class="entry-footer col-md-3 col-lg-2 col-lg-push-1">					
						<a href="/noticias/"><img src="<?php echo get_template_directory_uri(); ?>/img/btn-newslist.png" alt="mais not�cias" id="btn-newslist"></a> 
						<a href="/noticias" id="txt-newslist">mais not�cias</a> 
					</div>
					
					<div class="entry-footer col-md-4 col-lg-4 col-lg-push-1">
						<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo get_permalink() ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/btn-sharefb.png" alt="compartilhar no facebook"  id="btn-sharefb"></a> 
						<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo get_permalink() ?>" id="txt-sharefb">compartilhar no facebook</a>
					</div>
					
				<?php endwhile; ?>
				</div>
				
				<?php else : ?>
				<div class="row">
					<br />
					<div class="col-sm-12 col-md-10 col-md-push-1" style="background: white; min-height: 200px">
					<h2>P&aacute;gina n&atilde;o encontrada</h2>
					<?php $classes = get_body_class();
					if (in_array('error404',$classes)) { 
						if (strpos($_SERVER['REQUEST_URI'],'home/Default') !== false) { 
							header('Location:  http://www.harasrosamystica.com.br',TRUE,301);
							?><script>window.location = "http://www.harasrosamystica.com.br";</script>
							<?php
						}  elseif (strpos($_SERVER['REQUEST_URI'],'artigos/o_haras') !== false) {
							header('Location:  http://www.harasrosamystica.com.br/sobre',TRUE,301);
							?><script>window.location = "http://www.harasrosamystica.com.br/sobre";</script>
							<?php
						}
					} ?>
					</div>
				</div>
				<?php endif; ?>
			
        </div><!-- /.container article -->

    </div>

    </section>
<?php get_footer(); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>

<title>Haras Rosa Mystica</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="initial-scale=1, maximum-scale=1" />
<link href="https://fonts.googleapis.com/css?family=PT+Sans" rel="stylesheet">
<?php wp_head(); ?>
</head>

<body <?php body_class(isset($class) ? $class : ''); ?>>
  <div id="aspnetForm">
      
      <div id="body">
          <div id="page">
              <div id="shadow">
                  <header id="header">
                      <div class="body-header">
                          <div class="top-row">
                              <div class="container-fluid">
                                  <nav class="navbar navbar-default" role="navigation">
                                      <div class="navbar-header">
                                         <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
                                              <span class="sr-only">Toggle navigation</span>
                                              <span class="icon-bar"></span>
                                              <span class="icon-bar"></span>
                                              <span class="icon-bar"></span>
                                          </button>
                                          <div class="navbar-brand">
                                            <a href="/">
                                                <img src="<?php echo get_template_directory_uri(); ?>/img/logoHRM.png" class="img" alt="Haras Rosa Mystica" /><h1>Haras Rosa Mystica</h1>
                                            </a>
                                          </div>
                                      </div>
                                     <div class="collapse navbar-collapse" id="navbar-collapse-1">
                                          <ul class="nav navbar-nav center-block">
                                              <li id="item-01" class="firstItem"><a href="/">
                                                        Home</a></li>
                                              <li id="item-02"><a href="/sobre">
                                                        O Haras</a></li>
                                              <li id="item-06" class="lastItem"><a href="/contato-sobre-cavalos">
                                                        Contato</a></li>
                                          </ul>
                                      </div>
                                  </nav>
									<div class="container">
										<div class="row">
											<div class="col-md-3 col-md-offset-9">
											  <form role="search" method="get" class="input-group" action="<?php echo site_url(); ?>">
													<input type="search" class="form-control" id="search" placeholder="Busca" aria-describedby="search" value="" name="s">
													<span class="input-group-btn">
														<button class="btn btn-default" type="submit" id="search-button"><span class="glyphicon glyphicon-search"></span></button>
													</span>
													<script>
													  function key_down(e) {
														if(e.keyCode === 13) {
														if(jQuery("#search").is(":focus")) { jQuery("#search-button").trigger("click"); }
														}
													  }
													</script>
											</form>
											</div>
										</div>
									</div>
                              </div>
                          </div>
                      </div>
                  </header>

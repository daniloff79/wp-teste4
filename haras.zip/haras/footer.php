                  <footer>
                      <div class="footer">
                          <div class="container" <?php if(!is_front_page()) {?>class="top45"<?php } ?>>
                              <div class="row">                                  
                                  <div class="col-sm-4 col-md-4 redes">
                                          <div class="social-icons">
                                              <span>
                                                  <a href="https://pt-br.facebook.com/harasrosamystica/" target="_blank" title="Facebook Fan Page"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-facebook.png"alt="Facebook Fan Page" /></a>
                                              </span>
                                              <span>
                                                  <a href="https://www.instagram.com/harasrosamystica" target="_blank" title="Instagram"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-instagram.png"  alt="Instagram" /></a>
                                              </span>
											  <p class="hidden-xs"> /harasrosamystica</p>
                                          </div>
                                      
                                  </div>      
                                  <div class="hidden-xs col-sm-4 col-md-4 copyright">
										<p>Copyright &copy; Haras Rosa Mystica</p>
                                  </div>
                                  <div class="col-sm-4 col-md-4 developed">
                                      <p><a href="http://www.input.com.vc" target="_blank" title="desenvovido por by Input Tecnologia"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-input.png" width="74" height="61" alt="Input Tecnologia" /></a></p>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </footer>
              </div><!-- /#shadow -->
          </div><!-- /#page -->
      </div><!-- /#body -->
  

</div>

<?php wp_footer(); ?>	
</body>
</html>
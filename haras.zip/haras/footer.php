                  <footer>
                      <div class="footer">
                          <div class="container">
                              <div class="row">                                  
                                  <div class="col-sm-5 copyright">
                                      <p>Copyright &copy; 2017 - Haras Rosa Mystica</p>
                                  </div>
                                  
                                  <div class="col-sm-5 redes">
                                      <p>

                                      </p>
                                  </div>

                                  <div class="col-sm-2 developed">
                                      <p align="right"><a href="http://www.input.com.vc" target="_blank" title="desenvovido por by Input Tecnologia"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-input.png" width="74" height="61" alt="Input Tecnologia" /></a></p>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </footer>
              </div><!-- /#shadow -->
          </div><!-- /#page -->
      </div><!-- /#body -->
  

</form>


<?php wp_footer(); ?>	
</body>
</html>
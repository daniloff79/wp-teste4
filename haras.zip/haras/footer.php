                  <footer>
                      <div class="footer">
                          <div class="container" <?php if(!is_front_page()) {?>style="padding-top: 45px"<?php } ?>>
                              <div class="row">                                  
                                  <div class="col-md-4 redes">
                                          <div class="social-icons">
                                              <span>
                                                  <a href="https://www.instagram.com/harasrosamystica" target="_blank" title="Instagram"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-instagram.png" width="24" height="24" alt="Instagram" /></a>
                                              </span>
                                              <span>
                                                  <a href="https://pt-br.facebook.com/harasrosamystica/" target="_blank" title="Facebook Fan Page"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-face.gif" width="24" height="24" alt="Facebook Fan Page" /></a>
                                              </span>
                                          </div>
                                      
                                  </div>      
                                  <div class="col-md-4 copyright">
										<p>Copyright &copy; 2017 - Haras Rosa Mystica</p>
                                  </div>
                                  <div class="col-md-4 developed">
                                      <p><a href="http://www.input.com.vc" target="_blank" title="desenvovido por by Input Tecnologia"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-input.png" width="74" height="61" alt="Input Tecnologia" /></a></p>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </footer>
              </div><!-- /#shadow -->
          </div><!-- /#page -->
      </div><!-- /#body -->
  

</div>

<?php wp_footer(); ?>	
</body>
</html>
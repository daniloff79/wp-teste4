<?php

// adicionar thumbnails
add_theme_support( 'post-thumbnails' );

// largura padr�o
if ( ! isset( $content_width ) ) {
	$content_width = 1200;
}

function theme_enqueue() {
	wp_enqueue_script( 'bootstrap-script', get_template_directory_uri() . '/library/bootstrap.min.js', array( 'jquery' ), null, true );
	wp_enqueue_style( 'bootstrap-style', get_template_directory_uri() . '/library/bootstrap.min.css' );
	wp_enqueue_style( 'main-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'theme_enqueue', 1 );

// slug at body class
function add_slug_body_class( $classes ) {
	global $post;
	if ( isset($post) && !is_post_type_archive() )  {
		$classes[] = $post->post_type . '-' . $post->post_name;
	}
	return $classes;
}
add_filter( 'body_class', 'add_slug_body_class' );

// editor style
add_editor_style( 'library/style-editor.css' );

// add excerpt field to pages
function wpcodex_add_excerpt_support_for_pages() {
	add_post_type_support( 'page', 'excerpt' );
}
add_action( 'init', 'wpcodex_add_excerpt_support_for_pages' );

// tamanho do exceprt
function custom_excerpt_length( $length ) {
        return 30;
    }
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

// lista de tags/cavalos poss�veis.
function cavalo_certo() { ?>
   <script type="text/javascript">
		jQuery( "body.post-type-biometria #tagsdiv-post_tag h2 span" ).html("Cavalo");
		jQuery( "body.post-type-post #tagsdiv-post_tag" ).hide();	
		jQuery( "body.post-type-cavalo #tagsdiv-post_tag" ).hide();	
    </script>
    <?php
}
add_action( 'admin_footer-post.php',     'cavalo_certo' );
add_action( 'admin_footer-post-new.php', 'cavalo_certo' );

// avisa sobre tags
function tag_cavalo() { 
	echo '<style>';
    echo 'body.edit-tags-php h1.wp-heading-inline:after {content: "/cavalos";}';
    echo '</style>';
}
add_action( 'admin_head', 'tag_cavalo' );

// remove tag da lista de Biometrias
function remove_submenu() {
    remove_submenu_page( 'edit.php?post_type=biometria', 'edit-tags.php?taxonomy=post_tag&amp;post_type=biometria' );
}
add_action( 'admin_menu', 'remove_submenu', 999 );


?>
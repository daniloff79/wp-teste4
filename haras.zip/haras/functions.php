<?php

//Add thumbnail, automatic feed links and title tag support
add_theme_support( 'post-thumbnails' );

//Add content width (desktop default)
if ( ! isset( $content_width ) ) {
	$content_width = 1200;
}

function theme_enqueue() {
	wp_enqueue_script( 'bootstrap-script', get_template_directory_uri() . '/library/bootstrap.min.js', array( 'jquery' ), null, true );
	wp_enqueue_style( 'bootstrap-style', get_template_directory_uri() . '/library/bootstrap.min.css' );
	wp_enqueue_style( 'main-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'theme_enqueue', 1 );

// slug at body class
function add_slug_body_class( $classes ) {
	global $post;
	if ( isset($post) && !is_post_type_archive() )  {
		$classes[] = $post->post_type . '-' . $post->post_name;
	}
	return $classes;
}
add_filter( 'body_class', 'add_slug_body_class' );

// editor style
add_editor_style( 'library/style-editor.css' );

// add excerpt field to pages
function wpcodex_add_excerpt_support_for_pages() {
	add_post_type_support( 'page', 'excerpt' );
}
add_action( 'init', 'wpcodex_add_excerpt_support_for_pages' );

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>

<title>Haras Rosa Mystica</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="https://fonts.googleapis.com/css?family=PT+Sans" rel="stylesheet">

<link rel='stylesheet' href='https://prodweb.input.com.vc:347/wp-content/themes/haras/library/bootstrap.min.css' type='text/css' media='all' />
<link rel='stylesheet' href='https://prodweb.input.com.vc:347/wp-content/themes/haras/style.css' type='text/css' media='all' />
</head>

<body class="archive post-type-archive post-type-archive-biometria">

				<?php $cavalo = array ( $_SERVER['QUERY_STRING'] );
					  $args = array( 'post_type' => 'biometria', 'tag' => $cavalo[0] );	
					  $my_query = new WP_Query( $args );
				      if(have_posts()) : ?>
					  
					<div class="row">
				<?php while ( $my_query->have_posts() ) {
						$my_query->the_post();  ?>
					<div class="col-sm-6 col-md-4">
							<?php
							$posttags = get_the_tags();
							$count=0;
							if ($posttags) {
							  foreach($posttags as $tag) {
								$count++;
								if (1 == $count) {
								  //echo ucfirst($tag->name); 
								}
							  }
							}
							?> 
							<span class="biometria-data">Altura <?php $data = get_post_meta( $post->ID, 'wpcf-data', true ); 
							$dataformatada = date_i18n("F/Y", $data);	
							echo $dataformatada; ?></span>: 
							<span class="biometria-altura"><?php $meta1 = get_post_meta( $post->ID, 'wpcf-altura', true ); 
							echo $meta1. 'cm'; ?></span> &nbsp;
							<span class="biometria-peso"></span><br />
					</div>
					<br />
					<div class="clearfix visible-xs-block"><br /></div>
				<?php } ?>
				</div>
				<?php else : ?>
				<div class="row">
					<div class="col-sm-12" style="background: white; min-height: 200px">
					<h2>P&aacute;gina n&atilde;o encontrada</h2>
					</div>
				</div>
				<?php endif; ?>

</body>
</html>
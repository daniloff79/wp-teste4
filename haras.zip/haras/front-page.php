<?php get_header(); ?>
				  
<section>
                      
    <div id="special">
 
        <div class="container front-page">
            <div class="row">
                <div class="col-sm-12 cavalos">
				  
					<ul class="nav nav-pills menu-lotes">
						<li role="presentation" id="salto-li"><a href="#1" id="salto">Garanhões Salto</a></li>
						<li role="presentation" id="dressage-li"><a href="#2" id="dressage">Garanhões Dressage</a></li>
						<li role="presentation" id="a-venda-li" class="active"><a href="#3" id="a-venda">À venda</a></li>
					</ul>

					<script>
					 jQuery( document ).ready(function() {
						if(window.location.hash) {
							var hash = window.location.hash.substring(1);
							if (hash == '2') { dois(); }
							if (hash == '3') { tres(); }
						} else { um(); }
					});
					jQuery( "#salto" ).click(function() {
						um();						
						jQuery('.lista-lotes a').each(function() {
							var href = jQuery(this).attr('href');
							if (href) {
								href = href.split("#");	newhref = href[0]; jQuery(this).attr('href', newhref);
							}
						});
					});
					jQuery( "#dressage" ).click(function() { dois(); });
					jQuery( "#a-venda" ).click(function() { tres(); });
					</script>
					
					<div class="lista-lotes">
					
						<?php $args = array(
							'post_type' => 'cavalo',
							'posts_per_page' => -1,
							'orderby'=> 'title',
							'order' => 'ASC'
						);
						$the_query = new WP_Query( $args );  ?>
						<?php while( $the_query->have_posts() ) {
							$the_query->the_post(); 
							$replace = [ 'ã' => 'a', 'Ã' => 'A', ' ' => '-', 'à' => 'a' ];
							$cavalocategorias =  get_the_category($post->ID);
							$slug = get_post_field( 'post_name', get_post() );							
							?>
							<div class="row cavalo <?php foreach($cavalocategorias as $cat) { echo str_replace(array_keys($replace), $replace,$cat->name); echo ' '; } ?>">
							
								<div class="list-item-lotes"> 
									<div class="first-col col-md-4">
										  <div class="image">
												<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium'); ?></a>
										  </div>
									</div>
									<div class="col-md-8">
										<h2><?php the_title(); if(has_category( 'a-venda' )) {?> Mystic Rose<?php } ?></h2>										
										<p class="filiacao">
											<?php $meta1 = get_post_meta( $post->ID, 'wpcf-pai', true ); 
											echo $meta1; ?> x <?php $meta2 = get_post_meta( $post->ID, 'wpcf-avo-materno', true ); 
											echo $meta2; ?>
										</p>
										<p class="info-basica">
											<?php $meta3 = get_post_meta( $post->ID, 'wpcf-sexo-do-animal', true ); 
											echo ucfirst($meta3); // sexo ?> 
											<br />Cor <?php $meta4 = get_post_meta( $post->ID, 'wpcf-cor-da-pelagem', true ); 
											echo ucfirst($meta4); // cor ?> 
										</p>
										<?php $cavalo_slug = $post->post_name; ?>
										<div class="embed-responsive" style="height: 25px;">
											<iframe class="col-sm-12 col-md-6" src="/biometria/?<?php echo $cavalo_slug; ?>"></iframe>	
										</div>

										<div class="bar">
											  <p>
												  <a href="<?php the_permalink(); ?>" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-plus-sign"></span> Mais informações</a>
												  <a href="/contato-sobre-cavalos/?<?php echo $slug; ?>" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-envelope"></span> Contato</a>
											  </p>
										</div>
									</div>
								</div>
							
							</div>
						<?php }
						wp_reset_postdata();
						?>	  
						<br />
					</div>
                </div>
            </div>
        </div>

    </div>

</section>

<?php get_footer(); ?>            

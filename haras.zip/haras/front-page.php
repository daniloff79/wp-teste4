<?php get_header(); ?>
				  
<section>
                      
    <div id="special">
 
        <div class="container front-page">
            <div class="row">
                <div class="col-sm-12 cavalos">
                  <h2>Lotes</h2>
				  
					<ul class="nav nav-pills menu-lotes">
						<li role="presentation" id="todos-li" class="active"><a href="#" id="todos">Todos</a></li>
						<li role="presentation" id="garanhao-li"><a href="#" id="garanhao">Garanh�o</a></li>
						<li role="presentation" id="dressage-li"><a href="#" id="dressage">Dressage</a></li>
						<li role="presentation" id="salto-li"><a href="#" id="salto">Salto</a></li>
					</ul>

					<script>
					jQuery( "#todos" ).click(function() {
						jQuery( ".lista-lotes .cavalo" ).each(function() { jQuery( this ).show(); });
						jQuery( ".menu-lotes li" ).each(function() { jQuery( this ).removeClass("active"); });
						jQuery( "#todos-li" ).addClass("active");
					});
					jQuery( "#garanhao" ).click(function() {
						jQuery( ".lista-lotes .cavalo" ).each(function() { jQuery( this ).hide(); });
						jQuery( ".lista-lotes .garanhao" ).each(function() { jQuery( this ).show(); });
						jQuery( ".menu-lotes li" ).each(function() { jQuery( this ).removeClass("active"); });
						jQuery( "#garanhao-li" ).addClass("active");
					});
					jQuery( "#dressage" ).click(function() {
						jQuery( ".lista-lotes .cavalo" ).each(function() { jQuery( this ).hide(); });
						jQuery( ".lista-lotes .dressage" ).each(function() { jQuery( this ).show(); });
						jQuery( ".menu-lotes li" ).each(function() { jQuery( this ).removeClass("active"); });
						jQuery( "#dressage-li" ).addClass("active");
					});
					jQuery( "#salto" ).click(function() {
						jQuery( ".lista-lotes .cavalo" ).each(function() { jQuery( this ).hide(); });
						jQuery( ".lista-lotes .salto" ).each(function() { jQuery( this ).show(); });
						jQuery( ".menu-lotes li" ).each(function() { jQuery( this ).removeClass("active"); });
						jQuery( "#salto-li" ).addClass("active");
					});
					</script>
					
					<div class="lista-lotes">
					
						<?php $args = array(
							'post_type' => 'cavalo',
							'posts_per_page' => -1,
						);
						$the_query = new WP_Query( $args );  ?>
						<?php while( $the_query->have_posts() ) {
							$the_query->the_post(); 
							$replace = [ '�' => 'a', '�' => 'A', ' ' => '-', '�' => 'a' ];
							$cavalocategorias =  get_the_category($post->ID);
							$slug = get_post_field( 'post_name', get_post() );							
							?>
							<div class="row cavalo <?php foreach($cavalocategorias as $cat) { echo str_replace(array_keys($replace), $replace,$cat->name); echo ' '; } ?>">
							
								<div class="list-item-lotes"> 
									<div class="col- col-md-4">
										  <div class="image">
											  <a href="#" title=" ">
												  <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium'); ?></a>
											  </a>
										  </div>
									</div>
									<div class="col-md-8">
										<h2><?php the_title(); ?></h2>
										<br />
										<p class="filiacao">
											<?php $meta1 = get_post_meta( $post->ID, 'wpcf-pai', true ); 
											echo $meta1; ?> x <?php $meta2 = get_post_meta( $post->ID, 'wpcf-avo-materno', true ); 
											echo $meta2; ?>
										</p>
										<p style="margin-bottom: 0">
											<?php $meta3 = get_post_meta( $post->ID, 'wpcf-sexo-do-animal', true ); 
											echo ucfirst($meta3); // sexo ?> 
											<br />Cor <?php $meta4 = get_post_meta( $post->ID, 'wpcf-cor-da-pelagem', true ); 
											echo ucfirst($meta4); // cor ?> 
										</p>
										<?php $cavalo_slug = $post->post_name; ?>
										<div class="embed-responsive" style="height: 85px;">
											<iframe class="col-sm-12 col-md-6" src="/biometria/?<?php echo $cavalo_slug; ?>"></iframe>	
										</div>

										<div id="bar" class="bar">
											  <p>
												  <a href="<?php the_permalink(); ?>" class="btn btn-default btn-sm" type="button"><span class="glyphicon glyphicon-plus-sign"></span> Mais informa��es</a>
												  <a href="/contato-sobre-cavalos/?<?php echo $slug; ?>" class="btn btn-default btn-sm" type="button"><span class="glyphicon glyphicon-envelope"></span> Contato</a>
											  </p>
										</div>
									</div>
								</div>
							
							</div>
						<?php }
						wp_reset_postdata();
						?>	  
						<br />
					</div>
                </div>
            </div>
        </div>

    </div>

</section>

<?php get_footer(); ?>            

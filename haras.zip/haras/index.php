<?php get_header(); ?>
				  
<section>
                      
    <div id="container">
        <div class="container article">
			
				<?php if(have_posts()) : ?>
				
				<?php if(!is_search()) { ?>				
				<div class="row">
					<div class="col-sm-12">
						<ol class="breadcrumb">
							<li><a href="/">Home</a></li>
							<?php the_title( '<li class="active">', '</li> ' ); ?>
						</ol>
					</div>
				</div>
				<?php } else { ?><h2>Resultados de busca</h2><?php } ?>
				   
				<div class="row row1">
				<?php while ( have_posts() ) : the_post(); ?>
					<div class="col-sm-12">
					
						<?php if(!is_search()) { 
						the_title( '<h1 class="page-header">', '</h1>' ); 
						} else { ?>
						<a href="<?php the_permalink(); ?>" class="title-link"><?php the_title( '<h1 class="page-header">', '</h1>' ); ?></a>
						<?php } ?>
						
					</div>
				<?php endwhile; ?>
				</div>
				   
				<?php the_content(); ?>
				   
				<?php else : ?>
				<div class="row">
					<br />
					<div class="col-sm-12" style="background: white; min-height: 200px">
					<h2>P&aacute;gina n&atilde;o encontrada</h2>
					</div>
				</div>
				<?php endif; ?>
			
        </div><!-- /.container article -->
		<?php  if (is_page( 16 )) {
			$selecao = array ( $_SERVER['QUERY_STRING'] );
			if (!empty($selecao[0])) {
				$espaco = str_replace('%20', ' ', $selecao[0]);
				$traco = str_replace('-', ' ', $espaco); ?>
				<script>
					jQuery("#field_fxswx").val("Gostaria de mais informa��es sobre o cavalo <?php echo ucwords($traco); ?>")
				</script>
		<?php } } ?>
    </div>

    </section>
<?php get_footer(); ?>
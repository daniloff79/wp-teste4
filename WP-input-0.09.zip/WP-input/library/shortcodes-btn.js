jQuery(document).ready(function($) {

    tinymce.create('tinymce.plugins.wpse72394_plugin', {
        init : function(ed, url) {
		
            ed.addCommand('wpse72394_insert_shortcode', function() {
				alert("Copie o URL do anexo desejado");	
				jQuery( "#insert-media-button" ).trigger( "click" );
				setTimeout(function () {
					document.addEventListener('copy', function(e) {
						setTimeout(function () {
							var nome = prompt("Cole o URL copiado");	
							jQuery( ".media-modal button.media-modal-close" ).trigger( "click" );
							setTimeout(function () {
								var titulo = prompt("Qual o t�tulo");
								if (nome !== null) {
									if (titulo !== null) {
										shortcode = '\n[anexo nome="' + nome + '" titulo="' + titulo + '"]\n';
									} else {
										shortcode = '\n[anexo nome="' + nome + '"]\n';
									}
								} else {
									if (titulo !== null) {
								shortcode = '[anexo titulo="' + titulo + '"]\n';
									} else {
										shortcode = '\n[anexo]\n';									
									}
								} // cancelar puxando duas vezes
								ed.execCommand('mceInsertContent', 0, shortcode);
							}, 250);
						}, 250);
					});
				}, 500);

                });
            ed.addButton('wpse72394_button', {
				title : 'Inserir anexo com estilo', cmd : 'wpse72394_insert_shortcode', image: url + '/shortcodes-btn.png' 
				});	
        },   
    });
    // Register TinyMCE plugin
    tinymce.PluginManager.add('wpse72394_button', tinymce.plugins.wpse72394_plugin);
});
<?php
/* 
Theme Name: Input
Theme URI: http://www.input.com.br
*/

// adicionar thumbnails, remover vers�o, remover emojis
add_theme_support( 'post-thumbnails' );
remove_action( 'wp_head', 'wp_generator' );	
remove_action( 'wp_head', 'print_emoji_detection_script', 7);
remove_action( 'wp_print_styles', 'print_emoji_styles');
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );

// largura padr�o
if ( ! isset( $content_width ) ) {
	$content_width = 1200;
}

function theme_enqueue() {
	wp_enqueue_script( 'bootstrap-script', get_template_directory_uri() . '/library/bootstrap.min.js', array( 'jquery' ), null, true );
	wp_enqueue_style( 'bootstrap-style', get_template_directory_uri() . '/library/bootstrap.min.css' );
	wp_enqueue_style( 'main-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'theme_enqueue', 1 );

// slug na classe do body
function add_slug_body_class( $classes ) {
	global $post;
	if ( isset($post) && !is_post_type_archive() )  {
		$classes[] = $post->post_type . '-' . $post->post_name;
	}
	return $classes;
}
add_filter( 'body_class', 'add_slug_body_class' );

// menu principal
function register_menu() {
  register_nav_menu('header-menu',__( 'Menu principal' ));
}
add_action( 'init', 'register_menu' );

// classe ativa do menu
function special_nav_class ($classes, $item) {
    if (in_array('current-menu-item', $classes) ){
        $classes[] = 'active ';
    }
    return $classes;
}
add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);

// adiciona excerpt nas p�ginas
function wpcodex_add_excerpt_support_for_pages() {
	add_post_type_support( 'page', 'excerpt' );
}
add_action( 'init', 'wpcodex_add_excerpt_support_for_pages' );


// CSS no WP panel
add_editor_style( 'library/style-editor.css' );

// CSS no Admin
add_action('admin_head', 'my_column_width'); 
function my_column_width() {
    echo '<style type="text/css">';
    echo '.wpsm-collaps-C-review-notice{ display: none !important; }';
    echo '</style>';
}

// Bot�o para shortcodes
add_action('init', 'wpse72394_shortcode_button_init');
function wpse72394_shortcode_button_init() {
      if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') && get_user_option('rich_editing') == 'true')
           return; 
      add_filter("mce_external_plugins", "wpse72394_register_tinymce_plugin"); 
      add_filter('mce_buttons', 'wpse72394_add_tinymce_button');
}
function wpse72394_register_tinymce_plugin($plugin_array) {
    $plugin_array['wpse72394_button'] = get_template_directory_uri() . '/library/shortcodes-btn.js';
    return $plugin_array;
}
function wpse72394_add_tinymce_button($buttons) {
            //Add the button ID to the $button array
    $buttons[] = "wpse72394_button";
    return $buttons;
}

// shortcode para anexo
function anexo($atts){
    extract(shortcode_atts(array(
      'titulo' => 'T�tulo',
	  'data' => '',
	  'nome' => 'o anexo',
    ), $atts));
	
	$arqanexo = substr($nome, strrpos($nome, '/') + 1);
	$extensao = substr($nome, strripos($nome, '.') + 1);
	
	$arquivo = '<div class="panel panel-default">
			  <div class="panel-heading">
				<h3>'. $titulo .'</h3>';
	if (empty($data)) { } else { $arquivo .= '<p class="meta-data gray6">Data de publica��o: <span>'. $data .'</span></p>'; }
	$arquivo .= '</div>
			  <div class="panel-body">';
	if($extensao == pdf) {			  
		$arquivo .= '<a href="' .$nome .'" class="pdf">'. $arqanexo .'</a>';
	} elseif($extensao == mp3) {			  
		$arquivo .= '<a href="' .$nome .'" class="play">'. $arqanexo .'</a>';
	} elseif(($extensao == png) || ($extensao == jpg) || ($extensao == gif)) {
		$arquivo .= '<a href="' .$nome .'" class="img">'. $arqanexo .'</a>';	
	} else {
		$arquivo .= '<a href="' .$nome .'" class="link">'. $arqanexo .'</a>';	
	}
	$arquivo .= '</div>
			  </div>';
	return $arquivo;
}
add_shortcode('anexo', 'anexo');

// shortcode para full width colorido
function full_shortcode( $atts, $content = null ) {
	extract(shortcode_atts( array('cor' => 'bg-white'), $atts));
	return '	<div class="'. $cor .'">
		<div class="container">
			<div class="row">' . do_shortcode($content) . '
			</div>
		</div>
	</div>';
}
add_shortcode( 'full', 'full_shortcode' );

// shortcode para col-md-6
function col6_shortcode( $atts, $content = null ) {
	return '	<div class="col-md-6">
				' . do_shortcode($content) . '
			</div>';
}
add_shortcode( 'metade', 'col6_shortcode' );

// shortcode para col-md-4
function col4_shortcode( $atts, $content = null ) {
	return '	<div class="col-md-4">
				' . do_shortcode($content) . '
			</div>';
}
add_shortcode( 'terco', 'col4_shortcode' );


?>
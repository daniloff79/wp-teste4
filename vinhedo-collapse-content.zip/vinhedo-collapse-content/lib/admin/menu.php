﻿<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class wpsm_collapsed {
	private static $instance;
    public static function forge() {
        if (!isset(self::$instance)) {
            $className = __CLASS__;
            self::$instance = new $className;
        }
        return self::$instance;
    }
	
	private function __construct() {
		
		add_action('admin_enqueue_scripts', array(&$this, 'wpsm_collapsed_admin_scripts'));
        if (is_admin()) {
			add_action('init', array(&$this, 'collapsed_content_cpt'), 1);
			add_action('add_meta_boxes', array(&$this, 'wpsm_collapsed_meta_boxes_group'));
			add_action('admin_init', array(&$this, 'wpsm_collapsed_meta_boxes_group'), 1);
			add_action('save_post', array(&$this, 'add_collapsed_meta_box_save'), 9, 1);
			add_action('save_post', array(&$this, 'collapsed_settings_meta_box_save'), 9, 1);
		}
    }
	//admin script
	public function wpsm_collapsed_admin_scripts(){
		if(get_post_type()=="collapsed_content"){
			require_once('script.php');
		}
	}
	public function collapsed_content_cpt(){
		require_once('cpt-reg.php');
		add_filter( 'manage_edit-collapsed_content_columns', array(&$this, 'collapsed_content_columns' )) ;
		add_action( 'manage_collapsed_content_posts_custom_column', array(&$this, 'collapsed_content_manage_columns' ), 10, 2 );
	}
	function collapsed_content_columns( $columns ){
        $columns = array(
            'cb' => '<input type="checkbox" />',
            'title' => __( 'Collapsed Content' ),
            'shortcode' => __( 'Collapsed Content Shortcode' ),
            'date' => __( 'Date' )
        );
        return $columns;
    }

    function collapsed_content_manage_columns( $column, $post_id ){
        global $post;
        switch( $column ) {
          case 'shortcode' :
            echo '<input type="text" value="[colapsar id='.$post_id.']" readonly="readonly" />';
            break;
          default :
            break;
        }
    }
	
	function wpsm_collapsed_meta_boxes_group(){
		add_meta_box('add_collapsed', __('Adicionar conteúdo', wpshopmart_collapsed_c_text_domain), array(&$this, 'wpsm_add_cc_meta_box_function'), 'collapsed_content', 'normal', 'low' );
		add_meta_box('collapsed_setting', __('Shortcode e configurações', wpshopmart_collapsed_c_text_domain), array(&$this, 'wpsm_add_cc_setting_meta_box_function'), 'collapsed_content', 'side', 'low');
			
	}
	function wpsm_add_cc_meta_box_function($post){
		require_once('add-cc.php');
	}
	function wpsm_pic_cc_shortcode(){
		require_once('cc-custom-css.php');
	}
	function wpsm_cc_rateus_meta_box_function(){
		?>
		   <h1>Rate Us </h1>
		<?php 
	}
	function wpsm_add_cc_setting_meta_box_function($post){
		require_once('settings.php');
	}
	function add_collapsed_meta_box_save($PostID){
		require_once('data-post/cc-save-data.php');
	}
	function collapsed_settings_meta_box_save($PostID){
		require_once('data-post/cc-settings-save-data.php');
	}
	function wpsm_add_cc_designs_meta_box_function(){
		?>
		<style>
		#wpsm_cc_accordion_designs .hndle  , #wpsm_cc_accordion_designs .handlediv {
				display:none;
				
			}
			#wpsm_cc_accordion_designs{
				margin-top:20px;
				background:transparent;
				padding:0px;
				box-shadow:none;
				border:0px;
				border-bottom: 2px dashed rgba(0,0,0,0.2);
				margin-bottom:30px;
			}
			#wpsm_cc_accordion_designs  h1{
				
				font-weight:900;
				margin-bottom:30px;
			}
			#wpsm_cc_accordion_designs .wpsm_ribbon{
				right: 10px;
			}
			
		</style>
		<h1>Pro Version Designs template</h1>

		<?php		
		
	}
	function wpsm_pic_cc_more_pro(){
		?>
		<style>
			#wpsm_cc_more_pro{
			background:#fff!important;
			box-shadow: 0 0 20px rgba(0,0,0,.2);
			margin-top:40px;
			}
			#wpsm_cc_more_pro .hndle , #wpsm_cc_more_pro .handlediv{
			display:none;
			}
			#wpsm_cc_more_pro p{
			color:#000;
			font-size:15px;
			}
			.wpsm-theme-container {
				background: #fff;
				padding-left: 0px;
				padding-right: 0px;
				box-shadow: 0 0 20px rgba(0,0,0,.2);
			}
			.wpsm_site-img-responsive {
				display: block;
				width: 100%;
				height: auto;
			}
			.wpsm_product_wrapper {
				padding: 20px;
				overflow: hidden;
			}
			.wpsm_product_wrapper h3 {
				float: left;
				margin-bottom: 0px;
				color: #000 !important;
				letter-spacing: 0px;
				text-transform: uppercase;
				font-size: 18px;
				font-weight: 700;
				text-align: left;
				margin:0px;
			}
			.wpsm_product_wrapper h3 span {
				display: block;
				float: left;
				width: 100%;
				overflow: hidden;
				font-size: 14px;
				color: #919499;
				margin-top: 6px;
			}
			.wpsm_product_wrapper .price {
				float: right;
				font-size: 24px;
				color: #000;
				font-family: sans-serif;
				font-weight: 500;
			}
			.wpsm-btn-block {
				overflow: hidden;
				float: left;
				width: 100%;
				margin-top: 20px;
				display: block;
			}
			.portfolio_read_more_btn {
				border: 1px solid #1e73be;
				border-radius: 0px;
				margin-bottom: 10px;
				text-transform: uppercase;
				font-weight: 700;
				font-size: 15px;
				padding: 12px 12px;
				display: block;
				text-align:center;
				width:100%;
				border-radius: 2px;
				cursor: pointer;
				letter-spacing: 1px;
				outline: none;
				position: relative;
				text-decoration: none !important;
				color: #fff !important;
				-webkit-transition: all ease 0.5s;
				-moz-transition: all ease 0.5s;
				transition: all ease 0.5s;
				background: #1e73be;
				padding-left: 22px;
				padding-right: 22px;
			}

		</style>

	<?php 	
	}
	
} 
 
global $wpsm_collapsed;
$wpsm_collapsed = wpsm_collapsed::forge();
?>
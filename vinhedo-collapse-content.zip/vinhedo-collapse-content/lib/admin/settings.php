﻿<?php 
if ( ! defined( 'ABSPATH' ) ) exit;
$De_Settings = unserialize(get_option('wpsm_cc_default_Settings'));
 $PostId = $post->ID;
 $Settings = unserialize(get_post_meta( $PostId, 'Wpsm_collapsed_Settings', true));

		$option_names = array(
			"op_cl_icon" 		 => $De_Settings['op_cl_icon'],
			"enable_toggle"    	 => $De_Settings['enable_toggle'],
			"enable_ac_border"   => $De_Settings['enable_ac_border'],
			"acc_op_cl_align"    => $De_Settings['acc_op_cl_align'],
			"acc_title_icon_clr" => $De_Settings['acc_title_icon_clr'],
			"acc_desc_font_clr"  => $De_Settings['acc_desc_font_clr'],
			"title_size"         => $De_Settings['title_size'],
			"des_size"     		 => $De_Settings['des_size'],
			"font_family"     	 => $De_Settings['font_family'],
			"expand_option"      =>$De_Settings['expand_option'],
			"custom_css"         =>$De_Settings['custom_css'],
			);
			foreach($option_names as $option_name => $default_value) {
				if(isset($Settings[$option_name])) 
					${"" . $option_name}  = $Settings[$option_name];
				else
					${"" . $option_name}  = $default_value;
			}


			
		?>
<style>
			#collapsed_shortcode{
			background:#fff!important;
			box-shadow: 0 0 20px rgba(0,0,0,.2);
			}
			#collapsed_shortcode .hndle , #collapsed_shortcode .handlediv{
			display:none;
			}
			#collapsed_shortcode p{
			color:#000;
			font-size:15px;
			}
			#collapsed_shortcode input {
			margin-top: 5px;
			font-size: 16px;
			padding: 8px 10px;
			width:100%;
			}
</style>
<Script>

 //font slider size script
  jQuery(function() {
    jQuery( "#title_size_id" ).slider({
		orientation: "horizontal",
		range: "min",
		max: 30,
		min:5,
		slide: function( event, ui ) {
		jQuery( "#title_size" ).val( ui.value );
      }
		});
		
		jQuery( "#title_size_id" ).slider("value",<?php  if($title_size!=""){ echo $title_size; } else{ echo "22"; } ?> );
		jQuery( "#title_size" ).val( jQuery( "#title_size_id" ).slider( "value") );
    
  });
</script>
<Script>

 //font slider size script
  jQuery(function() {
    jQuery( "#des_size_id" ).slider({
		orientation: "horizontal",
		range: "min",
		max: 30,
		min:5,
		slide: function( event, ui ) {
		jQuery( "#des_size" ).val( ui.value );
      }
		});
		
		jQuery( "#des_size_id" ).slider("value",<?php  if($des_size!=""){ echo $des_size; } else{ echo "22"; } ?>);
		jQuery( "#des_size" ).val( jQuery( "#des_size_id" ).slider( "value") );
    
  });
</script> 
<Script>
function wpsm_update_default(){
	 jQuery.ajax({
		url: location.href,
		type: "POST",
		data : {
			    'action_cc':'default_settins_action',
			     },
                success : function(data){
									alert("Default Settings Updated");
									location.reload(true);
                                   }	
	});
	
}
</script>
<?php

if(isset($_POST['action_cc']) == "default_settins_action")
	{
	
		$Settings_Array2 = serialize( array(
			"op_cl_icon" 		 => $op_cl_icon,
			"enable_toggle"    	 => $enable_toggle,
			"enable_ac_border"   => $enable_ac_border,
			"acc_op_cl_align"    => $acc_op_cl_align,
			"acc_title_icon_clr" => $acc_title_icon_clr,
			"acc_desc_font_clr"  => $acc_desc_font_clr,
			"title_size"         => $title_size,
			"des_size"     		 => $des_size,
			"font_family"     	 => $font_family,
			"expand_option"      =>$expand_option,
			"custom_css"         =>$custom_css,
				) );

			update_option('wpsm_cc_default_Settings', $Settings_Array2);
}

 ?> 


<input type="hidden" id="wpsm_cc_setting_save_action" name="wpsm_cc_setting_save_action" value="wpsm_faq_setting_save_action">
	
<table class="form-table acc_table" style="">
	<tbody>
		<tr id="#collapsed_shortcode">
			<td>
			<h3 style="margin-top: -5px;">Shortcode</h3>
				<p>Selecione, copie o código abaixo e cole onde for necessário</p>
				<input readonly="readonly" type="text" value="<?php echo "[colapsar id=".get_the_ID()."]"; ?>" style="margin-top: 5px; color: #119911; border-color: #119911; background: white; margin-bottom: 25px">
			</td>
		</tr>
	</tbody>
</table>
	
<table class="form-table acc_table" style="">
	<tbody>
	<tr >
			<th scope="row"><label><?php _e('Collapse Title Color',wpshopmart_collapsed_c_text_domain); ?></label>
			</th>
			<td>
				<input id="acc_title_icon_clr" name="acc_title_icon_clr" type="text" value="<?php echo $acc_title_icon_clr; ?>" class="my-color-field" data-default-color="#cc0d2f" />
			</td>
		</tr>
		<tr >
			<th scope="row"><label><?php _e('Collapse Description Color',wpshopmart_collapsed_c_text_domain); ?></label>
			</th>
			<td>
				<input id="acc_desc_font_clr" name="acc_desc_font_clr" type="text" value="<?php echo $acc_desc_font_clr; ?>" class="my-color-field" data-default-color="#333333" />
			</td>
		</tr>
		
		<script>
		jQuery(function() {
		jQuery(".wpsm_off *").attr("disabled", "disabled").off('click');


		});
		
		</script>
	</tbody>
</table>
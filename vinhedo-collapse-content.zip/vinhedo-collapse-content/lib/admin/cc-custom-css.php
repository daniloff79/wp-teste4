<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<style>
			#collapsed_shortcode{
			background:#fff!important;
			box-shadow: 0 0 20px rgba(0,0,0,.2);
			}
			#collapsed_shortcode .hndle , #collapsed_shortcode .handlediv{
			display:none;
			}
			#collapsed_shortcode p{
			color:#000;
			font-size:15px;
			}
			#collapsed_shortcode input {
			font-size: 16px;
			padding: 8px 10px;
			width:100%;
			}
			
		</style>
		<?php
		 $PostId = get_the_ID();
		$Settings = unserialize(get_post_meta( $PostId, 'Wpsm_collapsed_Settings', true));
		if(isset($Settings['custom_css'])){  
		     $custom_css   = $Settings['custom_css'];
		}
		else{
		$custom_css="";
		}		
		?>
		
		<script>
		jQuery(function() {
		// Target a single one
		  jQuery("#custom_css").linedtextarea();

		});
		</script>
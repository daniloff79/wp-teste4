# shortcode-menu
Generates shortcode menu button in wordpress wysiwyg 

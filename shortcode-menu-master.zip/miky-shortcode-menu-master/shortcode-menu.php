<?php
/*
Plugin Name: Vinhedo Shortcode Menu
Description: Inclui shortcodes de forma amig�vel. Baseado em Shortcode Menu (github.com/justwalkit/miky-shortcode-menu)
Plugin URI: http://www.input.com.vc
Author: Danilo Fernandes Ferreira
Version: 2017.0.01
*/

$button_shortcodes = array();

if(is_admin())
{
    //require_once plugin_dir_path( __FILE__ ) . 'includes/coveloping-shortcode-admin-default-shortcodes.php';
    //new Coveloping_Shortcode_Admin_Default_Shortcodes();

    // Admin shortcode button tinymce
    require_once plugin_dir_path(__FILE__) . 'admin/coveloping-shortcode-admin-shortcode-tinymce.php';
    new Coveloping_Shortcode_Admin_Shortcode_Tinymce();

    // Admin shortcode form
    require_once plugin_dir_path(__FILE__) . 'admin/coveloping-shortcode-admin-shortcode-form.php';
    new Coveloping_Shortcode_Admin_Shortcode_Form();

    // Admin shortcode settings page
    //require_once plugin_dir_path( __FILE__ ) . 'admin/coveloping-shortcode-admin-shortcode-settings.php';
    //new Coveloping_Shortcode_Admin_Shortcode_Settings();

    // Admin shortcode ajax
    require_once plugin_dir_path( __FILE__ ) . 'admin/coveloping-shortcode-admin-shortcode-ajax.php';
    new Coveloping_Shortcode_Admin_Shortcode_Ajax();

    // Add Test shortcode
    //require_once plugin_dir_path(__FILE__) . 'tests/coveloping-shortcode-test-shortcode-form.php';
    //new Coveloping_Shortcode_Test_Shortcode_Form();
}
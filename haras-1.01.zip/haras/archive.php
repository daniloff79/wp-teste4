<?php get_header(); ?>
				  
<section>
                      
    <div id="container">
	
        <div class="container article">
			<?php if ( have_posts() ) : ?>
			<br />
			<div class="row">			
				<?php while ( have_posts() ) { 
					the_post();
					$replace = [ '�' => 'a', '�' => 'A', ' ' => '-', '�' => 'a' ];
					$cavalocategorias =  get_the_category();
				?>
                 <div class="col-sm-12 entry-content <?php foreach($cavalocategorias as $cat) { echo str_replace(array_keys($replace), $replace,$cat->name); echo ' '; } ?>">	
				
					<a href="<?php the_permalink(); ?>" class="title-link"><?php the_title( '<h1 class="page-header">', '</h1>' ); ?></a>
	
					<?php the_content(); ?>
					
				</div>
				<?php } ?>
			</div>

			<?php else : ?>
			<div class="row">
				<br />
				<div class="col-sm-12" style="background: white; min-height: 200px">
				<h2>P&aacute;gina n&atilde;o encontrada</h2>
				</div>
			</div>
			
			<?php endif; ?>
        </div><!-- /.container article -->
		
    </div>

</section>

<?php get_footer(); ?>
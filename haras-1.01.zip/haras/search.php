<?php get_header(); ?>
				  
<section>
                      
    <div id="container">
        <div class="container article">
			
				<?php if(have_posts()) : ?>
				
				<p class="resultado">A busca retornou <?php global $wp_query; echo $wp_query->found_posts; ?> resultado(s) para <b><?php echo get_search_query(); ?></b>, veja abaixo:</p>

				<div class="row row1">
				<?php while ( have_posts() ) : the_post(); ?>
					<div class="col-md-12">
						<a href="<?php the_permalink(); ?>" class="title-link"><?php the_title( '<h1 class="page-header">', '</h1>' ); ?></a>
						
						<?php if ( has_post_thumbnail() ) { ?>
						<div class="resultado-resumo">
							<?php the_excerpt(); ?>
						</div>
						<div class="resultado-img">
							<?php the_post_thumbnail('medium', array('class' => 'img-responsive')); ?>
						</div>
						<?php } else {
							the_excerpt();				
						} ?>
					</div>
				<?php endwhile; ?>
				</div>
				
				<?php else : ?>
				<div class="row">
					<br />
					<div class="col-sm-12" style="background: white; min-height: 200px">
					<p class="resultado">A busca n�o encontrou nada para <b><?php echo get_search_query(); ?></b>. Tente com outros termos:
					<form role="search" method="get" class="input-group" action="https://prodweb.input.com.vc:347">
						<input type="search" class="form-control" id="search2" placeholder="Busca" aria-describedby="search" value="" name="s">
						<span class="input-group-btn">
						<button class="btn btn-default" type="submit" id="search-button2"><span class="glyphicon glyphicon-search"></span></button>
						</span>
					</form>					
					</p>
					</div>
				</div>
				<?php endif; ?>
			
        </div><!-- /.container article -->
    </div>

    </section>
<?php get_footer(); ?>
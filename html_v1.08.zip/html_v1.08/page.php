<?php get_header(); ?>

		<div class="row" id="content">

			<div class="col-md-12 withbreadcrumb">

				<div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
				<?php if(function_exists('bcn_display')) {
					bcn_display();
				} ?>
				</div>

				<?php if(have_posts()) : ?>
				   <?php while(have_posts()) : the_post(); ?>
						<?php if( is_page('comissoes') ) { ?>
				<div id="post-<?php the_ID(); ?>" <?php post_class(); ?> style="font-size: 1em">
				<h1>Vereadores</h1>
				<div class="row gray3" id="filter" style="font-size: 1em">
					<div class="col-md-12" style="margin-bottom: 0; padding-left: 15px; padding-right: 15px">
						<span class="hidden-xs">Exibir:</span>
						<div class="form-inline">
							<a href="/vereador" id="partidolabel" class="hidden-xxs">Partido: </a>
							<select id="partido-filter" onchange="document.location.href=this.value">
								<option value="../vereador">todos</option>
								<option value="../vereador/?pdt">PDT</option>
								<option value="../vereador/?pmdb">PMDB</option>
								<option value="../vereador/?pmn">PMN</option>
								<option value="../vereador/?psb">PSB</option>
								<option value="../vereador/?psd">PSD</option>
								<option value="../vereador/?psdb">PSDB</option>
								<option value="../vereador/?pv">PV</option>
								<option value="../vereador/?rede">Rede</option>
							</select>					
						</div>
						<p><span class="separator hidden-sm hidden-xs hidden-xxs"> | </span>
							<a href="/vereador/?presidencia" id="presidencia" class=" hidden-sm hidden-xs">Presid�ncia</a>
							<span class="separator hidden-xs"> | </span>
							<a href="/vereador/?mesa" id="mesa" class="">Mesa diretiva</a>
							<span class="separator hidden-xxs"> | </span>
							<a href="/vereador/?lideres" id="lideres">Lideran�as</a>
							<span class="separator hidden-sm hidden-xs hidden-xxs"> | </span>
							<a href="#" id="comissoes" class=" hidden-sm hidden-xs hidden-xxs filtering">Comiss&otilde;es</a>
						</p>
					</div>
				</div>	
					<script>jQuery('#menu-item-192').addClass('active');</script>	
						<?php 
						the_content();
						} else { ?>
					<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						<?php
						if(!is_page('atividades-legislativas')) {
							the_title('<h2>','</h2>');
						} 
						the_content();
						} ?>
					</div>
				   <?php endwhile; ?>
				<?php else : ?>
				<div class="alert">
				  <strong>P&aacute;gina n&atilde;o encontrada</strong>
				</div>
				<?php endif; ?>
			</div>

		</div><!-- /#content -->

<?php get_footer(); ?>
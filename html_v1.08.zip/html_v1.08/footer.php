	<!-- Modal -->
	<div class="modal fade" id="modal01" tabindex="-1" role="dialog" aria-labelledby="modal01">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<div class="modal-body">
				<h4 class="red">Acessibilidade</h4>
				<p>No topo das páginas de nosso site, disponibilizamos uma barra de acessibilidade com atalhos de teclado, facilitando a navegação para quem utiliza o teclado, como pessoas cegas e com certas limitações físicas.</p>
				<h5>Utilizando os atalhos</h5>
				<p>Em nosso site, disponibilizamos os seguintes atalhos de teclado:<br />
				1: Ir para o conteúdo principal da página<br />
				<span class="visible-md visible-lg">2: Ir para o menu principal<br /></span><span class="visible-md visible-lg">3: Abrir estas informações sobre acessibilidade<br /></span>4: Alterar entre contraste normal e alto<br />5: Ir para página Mapa do Site</p>			
				<p>Cada navegador possui tecla ou teclas específicas para ativar os atalhos:<br />
				<b>Chrome:</b> Alt + [número do atalho] (Windows) ou Control + Option + [número do atalho] (Mac)<br /><b>Firefox:</b> Alt + Shift + [número do atalho] (Windows) ou Control + Option + [número do atalho] (Mac)<br /><b>Internet Explorer:</b> Alt + [número do atalho] (Windows) ou Control + [número do atalho] (Mac)<br /><b>Safari:</b> Alt + [número do atalho] (Windows) ou Control + Option + [número do atalho] (Mac)<br /><b>Opera:</b> Alt + [número do atalho]</p>
				<h5>Ampliando o texto no navegador</h5>
				<p>Pressione “Ctrl” + “+” (sinal de mais) para aumentar a fonte do texto;<br />Pressione “Ctrl” + “-” (sinal de menos) para diminuir a fonte do texto;<br />Pressione “Ctrl” + “0” (zero) para retornar ao tamanho padrão da fonte.<br />
				<br />No Mac OS, substitua o Ctrl pela tecla Command.</p>
			</div>
		</div>
	  </div>
	</div>
		<div class="row-fluid footer">
			<script src="<?php echo get_template_directory_uri(); ?>/library/bootstrap.js"></script>	
			<?php if( is_front_page() ) { ?>
			<script src="<?php echo get_template_directory_uri(); ?>/library/lightslider.js"></script>
				<div class="col-md-12 footer0">
				<h4 class="text-center gray6">Cadastre-se</h4>
				<p class="gray6">Informe o seu e-mail para receber notícias e novidades da Câmara de Vinhedo:</p>
				<?php echo do_shortcode( '[formidable id=6]' ) ?>
			</div>
			<?php } ?>
			<div class="col-md-12 hidden-sx hidden-sm footer1" id="sitemap"> 
				<?php if ( dynamic_sidebar('footer-map') ) : else : endif; ?>
			</div>
		</div>	
	</div> <!-- /#main-container -->
	<div id="subfooter">
		<div class="container">	
			<div class="row footer2">
				<div class="col-md-12">
					<p class="copyright">&copy; <span class="strong">2017 - Câmara Municipal de Vinhedo</span></p>
				</div>
				<div class="clearfix"></div>
				<div class="col-sd-6 col-md-5">
					<img src="<?php echo get_template_directory_uri(); ?>/images/ico-local.png" class="icon"><p>Av. Dois de Abril, 78 - Centro -<br class="visible-xxs" /> Vinhedo/SP - CEP 13280-077</p><br />
					<img src="<?php echo get_template_directory_uri(); ?>/images/ico-fone.png" class="icon"><p>(19) 3826-7700</p><br />
					<img src="<?php echo get_template_directory_uri(); ?>/images/ico-mail.png" class="icon"><p>imprensa@camaravinhedo.sp.gov.br</p>
				</div>
				<div class="col-sd-6 col-md-2">
					<img src="<?php echo get_template_directory_uri(); ?>/images/ico-chegar.png" class="icon"><p><a href="/localizacao">Como chegar</a></p>
				</div>
				<div class="col-sd-12 col-md-4">	
					<p class="hidden-xs">Número de visitas: 
					<?php echo do_shortcode( '[visitor_counter]' ) ?> 
					</p>					
				</div>
				<div class="col-md-1">
					<a href="http://www.input.com.vc" id="logo-input"><img src="<?php echo get_template_directory_uri(); ?>/images/logo-input.png" alt="Input Center Tecnologia"></a>
				</div>
			</div>
		</div>
	</div> <!-- /#subfooter -->	
	<?php if (has_tag('galeria')) { ?>
	<script>
		jQuery(document).ready(function() { console.log("Tempo até DOMready: ", Date.now()-timerStart); });
		jQuery(window).load(function() { console.log("Tempo pra tudo carregar: ", Date.now()-timerStart); 
		});
	</script>
	<?php } 
	if (is_front_page()) { ?>
	<script>
		var timerStart = Date.now();
	</script>
	<?php }?>
	<script>
		jQuery(".masthead nav #menu-item-1341 a").attr("target", "_blank");  // portal dos sevidores
		jQuery(".masthead nav #menu-item-1638 a").attr("target", "_blank"); // boletim municipal
		jQuery("#carousel-2-item-177").attr("target", "_blank"); // boletim municipal
	</script>

<?php wp_footer(); ?>	
</body>
</html>
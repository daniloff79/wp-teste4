﻿<?php get_header(); ?>

		<div class="row" id="content">

			<div class="col-md-12" style="margin-top: 10px">

				<?php if(have_posts()) : ?>
				   <?php while(have_posts()) : the_post(); ?>
					<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						 
						<?php if (!is_page( 'home' ) ) { the_title('<h2 class="title">','</h2>'); } ?>
						
						<div class="entry-content">	
							<?php the_content(); ?>
						</div>
					</div>
					<?php
					if (is_singular()) {
						// support for pages split by nextpage quicktag
						wp_link_pages();

						// Previous/next post navigation.
						//the_post_navigation();
					}
					?>
				   <?php endwhile; ?>

				<?php if (!is_singular()) : ?>

				<?php endif; ?>

				<?php else : ?>

				<div class="alert">
				  <strong>P&aacute;gina n&atilde;o encontrada</strong>
				</div>

				<?php endif; ?>
			</div>

		</div><!-- /#content -->

<?php get_footer(); ?>
﻿jQuery(document).ready(function($) {
	var rodou = 1;
    tinymce.create('tinymce.plugins.wpse72394_plugin', {
		init : function(ed, url) {
			// Register command for when button is clicked
			ed.addCommand('wpse72394_insert_shortcode', function() {
				setTimeout(function () {
					alert("Copie o URL");	
					jQuery( "#insert-media-button" ).trigger( "click" );
					document.addEventListener('copy', function(e) {
						setTimeout(function () {
							if ( rodou <= 4 ) {
								var url = prompt( "Cole o URL");	
								jQuery( ".media-modal button.media-modal-close" ).trigger( "click" );
								var titulo = prompt( "Digite o título");
								var data = prompt( "Digite o data");
								console.log(rodou);
								if (url !== null) {
									if (titulo !== null) {
										shortcode = '[anexo nome="' + url + '" titulo="' + titulo + '"]';
										if (data !== null) {
											shortcode = '[anexo nome="' + url + '" titulo="' + titulo + '" data ="' + data + '"]';	
										}
									} else {
									shortcode = '[anexo nome="' + url + '"]';
									}
								} else {
									shortcode = '[anexo]';
									}
							} // else { jQuery("#post-body-content").load(); }
							if ( rodou > 2 ) { setTimeout(function () { jQuery("#mceu_26").trigger( "click" ); }, 100); }
							if ( rodou > 3 ) { setTimeout(function () { jQuery("#mceu_26").trigger( "click" ); }, 500); }
							if ( rodou == 4 ) { setTimeout(function () { jQuery("#publish").trigger( "click" ); }, 100); }
							ed.execCommand('mceInsertContent', false, shortcode);
							rodou ++;
							// tinymce.execCommand('mceInsertContent', false, shortcode);
						}, 100);
					});
				}, 100);
			});
			ed.addButton('wpse72394_button', {
				title : 'Inserir anexo com estilo', cmd : 'wpse72394_insert_shortcode', image: url + '/shortcodes-btn.png' 
			});	
        },   
    });
    tinymce.PluginManager.add('wpse72394_button', tinymce.plugins.wpse72394_plugin);
	return false;	
});
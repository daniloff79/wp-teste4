﻿<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php if (is_page('2547')) { //tv câmara
		?><meta http-equiv="cache-control" content="max-age=172800" /><?php //48 horas
	}
	if ( !wp_is_mobile() ) { if (!is_page('2547')) { ?><meta http-equiv="refresh" content="630"><?php } } else { ?>
    <link rel="apple-touch-icon" href="<?php echo get_template_directory_uri(); ?>/images/apple-touch-icon.png">
	<?php } ?>
    <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png">		
	
	<?php
	wp_enqueue_script('jquery');
	if (has_tag('galeria')) {
		wp_enqueue_script('jquery-ui', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.6/jquery-ui.min.js', array('jquery'), '1.11.4,', true);
		wp_enqueue_style('jquery-ui-css', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css', true);
		wp_enqueue_script('jquery-ui-core', true);
		?><script>
	var timerStart = Date.now();
	</script>
	<?php };
	if (is_page('33') || (is_front_page())) { //home 
		wp_enqueue_style( 'front-page', get_template_directory_uri() . '/front-page.css' );
	?>
		<meta property="og:url" content="http://camaravinhedo.sp.gov.br" />
		<meta property="og:title" content="Site da Câmara Municipal de Vinhedo" />
	<?php } else {
	wp_enqueue_style( 'inner-css', get_template_directory_uri() . '/inner.css' );
	?>
		<meta property="og:url" content="<?php the_permalink(); ?>" />
		<meta property="og:title" content="<?php the_title(); ?>" />
		<meta property="og:image" content="<?php the_post_thumbnail_url(); ?>" />
		<meta property="og:description" content="<?php get_the_excerpt(); ?>" id="fbdescription" />
	<?php }; 
	if (is_post_type_archive()) {
	wp_enqueue_style( 'calendar-css', get_template_directory_uri() . '/calendar.css' );
	}
	?>
<meta name="google-site-verification" content="UhSZM0QH4vyXPjC4fQM8-3y1lOPMzdOe3bQS9GBnY2k" />
	<?php
	// wordpress head functions ?>
	<?php wp_head(); ?>
</head>
<body <?php body_class(isset($class) ? $class : ''); ?> itemscope itemtype="http://schema.org/WebPage">
	<div id="overheader">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-9 col-md-9">
					<div class="text-center">
						<span><a href="#content" accesskey="1">Ir para o conteúdo(1)</a></span>
						<span class="visible-md-inline-block visible-lg-inline-block"><a href="#menu-menu-principal" accesskey="2">Ir para a navegação(2)</a></span>
						<span class="visible-md-inline-block visible-lg-inline-block"><a href="#" accesskey="3" data-toggle="modal" data-target="#modal01">Acessibilidade(3)</a></span>
						<span><a onclick="jQuery('body').toggleClass('contrast');" accesskey="4" style="cursor: pointer">Alto contraste(4)</a></span>
						<span class="visible-md-inline-block visible-lg-inline-block"><a href="#sitemap" accesskey="5">Mapa do site(5)</a></span>
					</div>
				</div>
				<div class="col-sm-3 col-md-3 hidden-xs">
					<div class="text-right">
						<?php echo date_i18n( 'j \d\e F \d\e Y',  strtotime( get_the_time( "j \d\e F \d\e Y" ) ) ); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
	  ga('create', 'UA-99342163-1', 'auto');
	  ga('send', 'pageview');
	</script>
	<div id="main-container" class="container">
	
		<div class="row masthead">	
			<div class="col-sm-12 col-md-5 unfloatme-sm">
				<a class="navbar-brand" href="<?php echo home_url(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/logo-camara.png" srcset="<?php echo get_template_directory_uri(); ?>/images/logo-camara-hires.png 2x, <?php echo get_template_directory_uri(); ?>/images/logo-camara-hires.png 3x" alt="<?php bloginfo( 'name' ); ?>"></a>
			</div>
		
			<div class="col-sm-12 col-md-7 unfloatme-sm">	
				<div class="row">
					<div class="col-md-12 col-lg-12 top-right-links">
						<a href="/plano-plurianual-participativo-2018-20121" class="visible-lg-inline" id="banner-extra-01"><img src="<?php echo content_url('/uploads/2017/06/banner-plurianual.png'); ?>" alt="plano plurianual participativo"></a>
						<a href="/plano-plurianual-participativo-2018-20121" class="hidden-lg" id="banner-extra-01p"><img src="<?php echo content_url('/uploads/2017/06/banner-plurianual-p.png'); ?>" alt="plano plurianual participativo"></a>
						<a href="/transparencia" id="acesso-info"><img src="<?php echo get_template_directory_uri(); ?>/images/bn-acesso.png" alt="acesso à informação"></a>
						<a href="/tv-camara" id="tv-camera"><img src="<?php echo get_template_directory_uri(); ?>/images/bn-tv.png" alt="tv câmara"></a>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12 col-md-4 col-lg-3 social">
						<?php if(get_option('mytheme_display_facebook')) { ?>
						<a href="http://www.facebook.com/pages/<?php echo get_option('mytheme_facebook_username'); ?>" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/ico-facebook.png?v=1" alt="facebook"></a>
						<?php }
						if(get_option('mytheme_display_twitter')) { ?>
						<a href="http://twitter.com/<?php echo get_option('mytheme_twitter_username'); ?>" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/ico-twitter.png?v=1" alt="twitter"></a>
						<?php }
						if(get_option('mytheme_display_youtube')) { ?>						
						<a href="https://www.youtube.com/<?php echo get_option('mytheme_youtube_username'); ?>" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/ico-youtube.png?v=1" alt="youtube"></a>
						<?php } ?>
					</div>
					<div class="col-sm-12 col-md-8 col-lg-9">
						<form role="search" method="get" class="input-group" action="<?php echo site_url(); ?>">
							<input type="search" class="form-control" id="search" placeholder="Digite a palavra chave" aria-describedby="search" value="" name="s">
							<span class="input-group-btn">
								<button class="btn btn-default" type="submit" id="search-button">BUSCAR</button>
							</span>
							<script>
							  function key_down(e) {
								if(e.keyCode === 13) {
								if(jQuery("#search").is(":focus")) { jQuery("#search-button").trigger("click"); }
								}
							  }
							</script>
						</form>	
					</div>
				</div>
			</div>
			<div class="col-md-12">
				<nav>
					<div class="navbar-header">
						<h1 class="gray6 visible-xs">
						<?php
						$classes = get_body_class();
						if (in_array('home',$classes)) {
							?>Home<?php
						} elseif (in_array('page-institucional',$classes)) {
							?>Institucional<?php
						} elseif ((in_array('post-type-archive-vereador',$classes)) || (in_array('single-vereador',$classes))) {
							?>Vereadores<?php
						} elseif ((in_array('page-id-12',$classes)) || (in_array('parent-pageid-12',$classes))) {
							?>Atividades Legislativas<?php	
						} elseif (in_array('page-transparencia',$classes)) {
							?>Transparência<?php	
						} elseif ((in_array('blog',$classes)) || (in_array('single',$classes))) {
							?>Notícias<?php	
						} elseif (in_array('page-localizacao',$classes)) {
							?>Localização<?php		
						} elseif (in_array('page-contato',$classes)) {
							?>Contato<?php	
						}
						?>											
						</h1>						
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#barra">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>
					<div class="collapse navbar-collapse" id="barra">
					<?php wp_nav_menu( array('menu' => 'Top menu', 'menu_class' => 'nav nav-justified',  'container'=> false, 'walker'=> new Bootstrap_Top_Menu)); ?>
					</div>
				</nav>
			</div>
			
		</div> <!-- /.masthead -->
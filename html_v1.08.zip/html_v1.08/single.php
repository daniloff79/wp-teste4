<?php get_header(); ?>
		<div class="row" id="content">

			<div class="col-md-8 withbreadcrumb">

				<div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
				<?php if(function_exists('bcn_display'))
				{
					bcn_display();
				}?>
				</div>

				<?php if(have_posts()) : ?>
				   <?php while(have_posts()) : the_post(); ?>
				   <?php $classes = get_body_class();
				   if (in_array('single-tf_events',$classes)) { ?>
						<div id="post-<?php the_ID(); ?>" <?php post_class('entry-content'); ?> itemscope itemtype="http://schema.org/Event">
						<?php the_title('<h1 class="title" itemprop="name">','</h1>'); ?>
					<?php } else { ?> 
						<div id="post-<?php the_ID(); ?>" <?php post_class('entry-content'); ?>>
						<?php the_title('<h1 class="title">','</h1>'); 
					}
						$subtitle = get_post_meta( $post->ID, 'wpcf-subtitulo', true ); 
						$subtitlefacil = str_replace('"', "", $subtitle);
						$subtitlefacil = str_replace("'", "", $subtitlefacil);
						if (empty($subtitlefacil[0])) {
							$subtitlefacil = get_the_excerpt();
							$subtitlefacil = str_replace('"', "", $subtitlefacil);
							$subtitlefacil = str_replace("'", "", $subtitlefacil);
							$subtitlefacil = str_replace("a href", "", $subtitlefacil);
							$subtitlefacil = array_shift(explode('=', $subtitlefacil));
							$subtitlefacil = str_replace("<a class", "", $subtitlefacil);
							$subtitlefacil = str_replace("<", "", $subtitlefacil);
							$subtitlefacil = str_replace(">", "", $subtitlefacil);
						} 
						if (get_post_meta( $post->ID, 'wpcf-subtitulo', true )) {
							echo "<h3 class='subtitle'>";
							echo $subtitle;
							echo "</h3>";
						}
						if (in_array('single-tf_events',$classes)) {
							$custom = get_post_custom();
							$startd = $custom["wpcf-data-de-inicio"][0];
							$startdate = date_i18n( 'l, d/m/Y, H:i', $startd ); 		
							?><h6 class="entry-date"><?php echo ucfirst($startdate); ?></h6><?php
						}
						else {
							if( !wp_is_mobile() ) {
								date_i18n( 'j \d\e F \d\e Y', the_date( 'j \d\e F \d\e Y', '<h6 class="entry-date">', '</h6>' ) );								
							}							
							else {
								date_i18n( 'j/M/Y', the_date( 'j/M/Y', '<h6 class="entry-date">', '</h6>' ) );
							}
						}
						echo do_shortcode( '[social]' );						
						if(!has_tag('galeria')) {
						the_post_thumbnail( 'cem' );
						}
						if(!has_category(array(62,63))) {						
							the_content();
						} else {
							the_content();
							$anexo = get_post_meta( get_the_ID(), 'wpcf-pdf-anexo',true);
							$filetype = wp_check_filetype($anexo);
							if($filetype['ext'] == pdf) {
								$arqanexo = substr($anexo, strrpos($anexo, '/') + 1);
							} else { $arqanexo = $anexo; }
							echo "<div class='panel-body'>";
							echo "<a href='";
							echo $anexo;
							if($filetype['ext'] == pdf) {
								echo "' class='pdf'>";
							} else { echo "' class='link'>"; }
							echo $arqanexo;
							echo "</a></div>";
						}
						?>
						
					</div>

					<?php if ( comments_open() ) { comments_template();	} ?>
					
					<script>jQuery("#fbdescription").attr("content", "<?php echo $subtitlefacil ?>"); </script>
					
				    <?php endwhile; ?>

				<?php else : ?>
				<div class="alert">
				  <strong>P&aacute;gina n&atilde;o encontrada</strong>
				</div>
				<?php endif; ?>
			</div>
			
			<div class="col-md-4 last-news" style="margin-top: 62px">
					<?php echo do_shortcode( '[recent-posts n="5"]' ) ?> 
			</div>

		</div><!-- /#content -->

<?php get_footer(); ?>
					<?php if ( post_password_required() ) { ?>
					<div class="alert">
						<h3><b>Este texto est&aacute; protegido por password. Insira-a para ver os coment&aacute;rios.</b></h3>
					</div>	
					<?php return; } ?>

					<div id="comments" class="comments-area">
					<?php if ( have_comments() ) { ?>
						<div class="row">
							<div class="col-md-12">
								<h4>Coment&aacute;rios</h4>
							</div>
						</div>
						<div class="row">
							<ol class="comment-list">
							<?php wp_list_comments( 'type=comment&callback=bla' ); ?>
							</ol>
						</div>	
					<?php } else { ?>
						<script>jQuery('#comments').addClass('no-comments')</script>
					<?php }
					if ( comments_open() ) {
					$commenter = wp_get_current_commenter();
					$fields =  array(
						'author' => '<div class="col-md-6">
									<label for="author" class="control-label">Nome</label>
									<input type="text" class="form-control" id="author" name="author" value="' . esc_attr( $commenter['comment_author'] ) . '" required>  
									</div>',
						'email'  => '<div class="col-md-6">
									<label for="email" class="control-label">E-mail</label>
									<input type="email" class="form-control" id="email" name="email" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" required>  
									</div>',
					);					 
					$comments_args = array(
						'fields' =>  $fields,
						'comment_notes_before' =>  '',
						'class_form' => 'row',
						'cancel_reply_before' => '',
						'title_reply' => '<div class="col-md-12">
										<span class="h4">Enviar coment&aacute;rio</span>
										</div>',
						'comment_field' => '<div class="col-md-12" style="margin-top: 15px">
										<label for="comment" class="control-label">Mensagem</label>
										<textarea class="form-control" id="comment" name="comment" rows="4" maxlength="65525" aria-required="true" required="required"></textarea>
										</div>',
						'label_submit' => 'enviar',
						'class_submit' => 'btn btn-default',
					);
										
					comment_form($comments_args);
					
					} else { ?>
					<div class="alert">
						<h3><b>Este texto est&aacute; protegido.</b></h3>
					</div>							
					<?php } ?>
					</div><!-- /#comments -->

<?php 
/**
 * Listagem de vereadores
 */
get_header(); ?>

		<div class="row" id="content">

			<div class="col-md-12 withbreadcrumb">
			
				<div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
				<?php if(function_exists('bcn_display'))
				{
					bcn_display();
				}?>
				</div>
				
				<h2>Vereadores</h2>

				<div class="row gray3" id="filter">
					<div class="col-md-12">
						<span class="hidden-xs">Exibir:</span>
						<div class="form-inline">
							<?php $selecao = array ( $_SERVER['QUERY_STRING'] ); ?>
							<a href="#" id="partidolabel" onclick="window.location.search='todos';jQuery('#partidolabel').addClass('filtering');jQuery('#mesa').removeClass('filtering');jQuery('#liders').removeClass('filtering')" class="<?php if( (empty($selecao[0])) || ($selecao[0] != mesa && $selecao[0] != lidereres )) { echo "filtering"; } ?> hidden-xxs">Partido: </a>
							<select id="partido-filter" onchange="window.location.search=this.value;" onfocus="jQuery('#partidolabel').addClass('filtering');jQuery('#mesa').removeClass('filtering');jQuery('#liders').removeClass('filtering')" >
								<option <?php if ( (empty($selecao[0])) || $selecao[0] == 'todos' ) { echo "selected"; } ?> value="todos">todos</option>
								<!-- <option <?php if($selecao[0] == 'dem') { echo "selected"; } ?> value="dem">DEM</option> -->
								<!--  <option <?php if($selecao[0] == 'novo') { echo "selected"; } ?> value="novo">Novo</option> -->
								<!-- <option <?php if($selecao[0] == 'pcb') { echo "selected"; } ?> value="pcb">PCB</option> -->
								<!-- <option <?php if($selecao[0] == 'pcdob') { echo "selected"; } ?> value="pcdob">PCdoB</option> -->
								<!-- option <?php if($selecao[0] == 'pco') { echo "selected"; } ?> value="pco">PCO</option> -->
								<option <?php if($selecao[0] == 'pdt') { echo "selected"; } ?> value="pdt">PDT</option>
								<!--  <option <?php if($selecao[0] == 'pen') { echo "selected"; } ?> value="pen">PEN</option> -->
								<!-- <option <?php if($selecao[0] == 'phs') { echo "selected"; } ?> value="phs">PHS</option> -->
								<!-- <option <?php if($selecao[0] == 'pmb') { echo "selected"; } ?> value="pmb">PMB</option> -->
								<option <?php if($selecao[0] == 'pmdb') { echo "selected"; } ?> value="pmdb">PMDB</option>
								<option <?php if($selecao[0] == 'pmn') { echo "selected"; } ?> value="pmn">PMN</option>
								<!-- <option <?php if($selecao[0] == 'pp') { echo "selected"; } ?> value="pp">PP</option> -->
								<!-- <option <?php if($selecao[0] == 'pp') { echo "selected"; } ?> value="ppl">PPL</option> -->
								<!-- <option <?php if($selecao[0] == 'pps') { echo "selected"; } ?> value="pps">PPS</option> -->
								<!-- <option <?php if($selecao[0] == 'pr') { echo "selected"; } ?> value="pr">PR</option> -->
								<!-- <option <?php if($selecao[0] == 'prb') { echo "selected"; } ?> value="prb">PRB</option> -->
								<!-- <option <?php if($selecao[0] == 'pros') { echo "selected"; } ?> value="pros">PROS</option> -->
								<!-- <option <?php if($selecao[0] == 'prp') { echo "selected"; } ?> value="prp">PRP</option> -->
								<!-- <option <?php if($selecao[0] == 'prtb') { echo "selected"; } ?> value="prtb">PRTB</option> -->
								<option <?php if($selecao[0] == 'psb') { echo "selected"; } ?> value="psb">PSB</option>
								<!-- <option <?php if($selecao[0] == 'psc') { echo "selected"; } ?> value="psc">PSC</option> -->
								<option <?php if($selecao[0] == 'psd') { echo "selected"; } ?> value="psd">PSD</option>
								<option <?php if($selecao[0] == 'psdb') { echo "selected"; } ?> value="psdb">PSDB</option>
								<!-- <option <?php if($selecao[0] == 'psdc') { echo "selected"; } ?> value="psdc">PSDC</option> -->
								<!-- <option <?php if($selecao[0] == 'psl') { echo "selected"; } ?> value="psl">PSL</option> -->
								<!-- <option <?php if($selecao[0] == 'psol') { echo "selected"; } ?> value="psol">PSOL</option> -->
								<!-- <option <?php if($selecao[0] == 'pstu') { echo "selected"; } ?> value="pstu">PSTU</option> -->
								<!-- <option <?php if($selecao[0] == 'pt') { echo "selected"; } ?> value="pt">PT</option> -->
								<!-- <option <?php if($selecao[0] == 'ptc') { echo "selected"; } ?> value="ptc">PTC</option> -->
								<!-- <option <?php if($selecao[0] == 'ptb') { echo "selected"; } ?> value="ptb">PTB</option> -->
								<!-- <option <?php if($selecao[0] == 'ptodb') { echo "selected"; } ?> value="ptdob">PTdoB</option> -->
								<!-- <option <?php if($selecao[0] == 'ptn') { echo "selected"; } ?> value="ptn">PTN</option> -->
								<option <?php if($selecao[0] == 'pv') { echo "selected"; } ?> value="pv">PV</option>
								<option <?php if($selecao[0] == 'rede') { echo "selected"; } ?>  value="rede">Rede</option>
								<!-- <option <?php if($selecao[0] == 'sd') { echo "selected"; } ?> value="sd">SD</option> -->
							</select>					
						</div>
						<p><span class="separator hidden-sm hidden-xs hidden-xxs"> | </span>
							<a href="#" id="presidencia" onclick="window.location.search='presidencia';jQuery('#partidolabel').removeClass('filtering');jQuery('#presidencia').addClass('filtering');jQuery('#mesa').removeClass('filtering');jQuery('#liders').removeClass('filtering')" class="<?php if($selecao[0] == 'presidencia') { echo "filtering"; }?>  hidden-sm hidden-xs">Presid�ncia</a>
							<span class="separator hidden-xs"> | </span>
							<a href="#" id="mesa" onclick="window.location.search='mesa';jQuery('#partidolabel').removeClass('filtering');jQuery('#presidencia').removeClass('filtering');jQuery('#mesa').addClass('filtering');jQuery('#liders').removeClass('filtering')" class="<?php if($selecao[0] == 'mesa') { echo "filtering"; } ?>">Mesa diretiva</a>
							<span class="separator hidden-xxs"> | </span>
							<a href="#" id="lideres" onclick="window.location.search='lideres';jQuery('#partidolabel').removeClass('filtering');jQuery('#presidencia').removeClass('filtering');jQuery('#mesa').removeClass('filtering');jQuery('#liders').addClass('filtering')" class="<?php if($selecao[0] == 'lideres') { echo "filtering"; } ?>">Lideran&ccedil;as</a>
							<span class="separator hidden-sm hidden-xs hidden-xxs"> | </span>
							<a href="/comissoes" id="comissoes" class="hidden-sm hidden-xs hidden-xxs">Comiss&otilde;es</a>
						</p>
					</div>
				</div><!-- /#filter -->

				<?php 
				echo "<script>console.log( 'partido: " . $selecao[0] . "' );</script>";  
				if ( (empty( $selecao[0])) || $selecao[0] == 'todos' ) {
					$args = array( 'post_type' => 'vereador', 'orderby'=> 'title', 'order' => 'ASC' );									
				} elseif ( $selecao[0] == 'presidencia' ) {
					echo "<script>jQuery('#partidolabel').removeClass('filtering')</script>";
					$args = array( 'post_type' => 'vereador', 'orderby'=> 'title', 'order' => 'ASC', 'category_name' => 'presidente' );		
				} elseif ( $selecao[0] == 'mesa' ) {
					echo "<script>jQuery('#partidolabel').removeClass('filtering')</script>";
					$args = array( 'post_type' => 'vereador', 'orderby'=> 'title', 'order' => 'ASC', 'category_name' => 'mesa' );		
				} elseif ( $selecao[0] == 'lideres' ) {
					echo "<script>jQuery('#partidolabel').removeClass('filtering')</script>";
					$args = array( 'post_type' => 'vereador', 'orderby'=> 'title', 'order' => 'ASC', 'category_name' => 'lider' );					
				} else {
					$args = array( 'post_type' => 'vereador', 'tax_query' => array( array ( 'taxonomy' => 'partido',
					'field' => 'slug', 'terms' => $selecao[0] ),), 'orderby'=> 'title', 'order' => 'ASC' );
				}  ?>
				<?php $my_query = new WP_Query( $args ); ?>
				<?php if(have_posts()) : ?>
				<div id="flex-me">
				<?php
				   while ( $my_query->have_posts() ) {
						$my_query->the_post(); 
						
						if ( $selecao[0] != 'lideres' ) { ?>
						
						<div id="post-<?php the_ID(); ?>" <?php post_class('col-sd-6 col-md-3 list-vereadores'); ?>> 				 
							<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
							<?php the_post_thumbnail( 'full' ); ?></a>
							<div class="entry-meta">
							<img src="<?php 
									$terms = get_the_terms( $post->ID, 'partido' );
									if ($terms) {
										$terms_name = array();
										foreach ( $terms as $term ) {
											$terms_name[] = $term->slug;
										}
										$sigla = $terms_name[0];
										echo get_template_directory_uri();
										echo "/images/partidos/";
										if(empty($sigla)) { echo "0"; } else { echo $sigla; }
										echo ".png";
									} ?>" class="partido">
							<!-- <h3> $terms = get_the_terms( $post->ID, 'partido' ) </h3> -->
							<?php the_title('<h3 class="gray6">','</h3>'); 
							if($selecao[0] == 'mesa' ) { 
								if( in_category( 'presidente' ) ) 
									{ echo "<h4 class='gray9'>Presidente</h4>"; ?><script>jQuery('.category-presidente').addClass('vereador-1');</script><?php }
									elseif(strpos(get_the_title(), 'Ana') !== false) { echo "<h4 class='gray9'>Vice-Presidente</h4>"; ?><script>jQuery('#post-182').addClass('vereador-2');</script><?php }
									elseif(strpos(get_the_title(), 'Edu') !== false) { echo "<h4 class='gray9'>1&ordm; Secret&aacute;rio</h4>"; ?><script>jQuery('#post-298').addClass('vereador-3');</script><?php }
									elseif(strpos(get_the_title(), 'Carlos') !== false) { echo "<h4 class='gray9'>2&ordm; Secret&aacute;rio</h4>"; ?><script>jQuery('#post-195').addClass('vereador-4');</script><?php }
								}									
							if($selecao[0] == 'lideres' ) { 
								echo "<h4 class='gray9'>L&iacute;der</h4>";
								} ?>
							</div>
						</div>
						
				   <?php } else { ?>
					
						<div id="post-<?php the_ID(); ?>" <?php post_class('col-sm-12 col-md-6 list-lideres'); ?>> 				 
							<a href="<?php the_permalink(); ?>"><img src="<?php 
									$terms = get_the_terms( $post->ID, 'partido' );
									if ($terms) {
										$terms_name = array();
										foreach ( $terms as $term ) {
										$terms_name[] = $term->slug;
										}
										$sigla = $terms_name[0];
										echo get_template_directory_uri(); 
										echo "/images/partidos-large/";
										if(empty($sigla)) { echo "0"; } else { echo $sigla; }
										echo ".png";
									} ?>" class="partido-large"></a>
									<?php if($sigla == 'dem') { ?><h5><?php echo "DEM - Democratas"; ?></h5><?php } ?>
									<?php if($sigla == 'novo') { ?><h5><?php echo "Novo - Partido Novo"; ?></h5><?php } ?>
									<?php if($sigla == 'pcb') { ?><h5><?php echo "PCB - Partido Comunista Brasileiro"; ?></h5><?php } ?>
									<?php if($sigla == 'pcdpb') { ?><h5><?php echo "PCdoB - Partido Comunista do Brasil"; ?></h5><?php } ?>
									<?php if($sigla == 'pco') { ?><h5><?php echo "PCO - Partido da Causa Oper�ria"; ?></h5><?php } ?>
									<?php if($sigla == 'pdt') { ?><h5><?php echo "PDT - Partido Democr�tico Trabalhista"; ?></h5><?php } ?>
									<?php if($sigla == 'pen') { ?><h5><?php echo "PEN - Partido Ecol�gico Nacional"; ?></h5><?php } ?>
									<?php if($sigla == 'phs') { ?><h5><?php echo "PHS - Partido Humanista da Solidariedade"; ?></h5><?php } ?>
									<?php if($sigla == 'pmb') { ?><h5><?php echo "PMB - Partido da Mulher Brasileira"; ?></h5><?php } ?>
									<?php if($sigla == 'pmdb') { ?><h5><?php echo "PMDB - Partido do Movimento Democr�tico Brasileiro"; ?></h5><?php } ?>
									<?php if($sigla == 'pmn') { ?><h5><?php echo "PMN - Partido da Mobiliza��o Nacional"; ?></h5><?php } ?>
									<?php if($sigla == 'pp') { ?><h5><?php echo "PP - Partido Progressista"; ?></h5><?php } ?>
									<?php if($sigla == 'ppl') { ?><h5><?php echo "PPL - artido P�tria Livre"; ?></h5><?php } ?>
									<?php if($sigla == 'pps') { ?><h5><?php echo "PPS - Partido Popular Socialista"; ?></h5><?php } ?>
									<?php if($sigla == 'pr') { ?><h5><?php echo "PR - Partido da Rep�blica"; ?></h5><?php } ?>
									<?php if($sigla == 'prb') { ?><h5><?php echo "PRB - Partido Republicano Brasileiro"; ?></h5><?php } ?>
									<?php if($sigla == 'pros') { ?><h5><?php echo "PROS - Partido Republicano da Ordem Social"; ?></h5><?php } ?>
									<?php if($sigla == 'prp') { ?><h5><?php echo "PRP - Partido Republicano Progressista"; ?></h5><?php } ?>
									<?php if($sigla == 'prtb') { ?><h5><?php echo "PRTB - Partido Renovador Trabalhista Brasileiro"; ?></h5><?php } ?>
									<?php if($sigla == 'psb') { ?><h5><?php echo "PSB - Partido Socialista Brasileiro"; ?></h5><?php } ?>
									<?php if($sigla == 'psc') { ?><h5><?php echo "PSC - Partido Social Crist�o"; ?></h5><?php } ?>
									<?php if($sigla == 'psd') { ?><h5><?php echo "PSD - Partido Social Democr�tico"; ?></h5><?php } ?>
									<?php if($sigla == 'psdb') { ?><h5><?php echo "PSDB - Partido da Social Democracia Brasileira"; ?></h5><?php } ?>
									<?php if($sigla == 'psdc') { ?><h5><?php echo "PSDC - Partido Social Democrata Crist�o"; ?></h5><?php } ?>
									<?php if($sigla == 'psl') { ?><h5><?php echo "PSL - Partido Social Liberal"; ?></h5><?php } ?>
									<?php if($sigla == 'psol') { ?><h5><?php echo "PSOL - Partido Socialismo e Liberdade"; ?></h5><?php } ?>
									<?php if($sigla == 'pstu') { ?><h5><?php echo "PSTU - Partido Socialista dos Trabalhadores Unificado"; ?></h5><?php } ?>
									<?php if($sigla == 'pt') { ?><h5><?php echo "PT - Partido dos Trabalhadores"; ?></h5><?php } ?>
									<?php if($sigla == 'ptc') { ?><h5><?php echo "PTC - Partido Trabalhista Crist�o"; ?></h5><?php } ?>
									<?php if($sigla == 'ptb') { ?><h5><?php echo "PTB - Partido Trabalhista Brasileiro"; ?></h5><?php } ?>
									<?php if($sigla == 'ptodb') { ?><h5><?php echo "PTdoB - Partido Trabalhista do Brasil"; ?></h5><?php } ?>
									<?php if($sigla == 'ptn') { ?><h5><?php echo "PTN - Partido Trabalhista Nacional"; ?></h5><?php } ?>
									<?php if($sigla == 'pv') { ?><h5><?php echo "PV - Partido Verde"; ?></h5><?php } ?>
									<?php if($sigla == 'rede') { ?><h5><?php echo "Rede - Rede Sustentabilidade"; ?></h5><?php } ?>
									<?php if($sigla == 'sd') { ?><h5><?php echo "SD - Solidariedade"; ?></h5><?php } ?>
							<p>L�der do Partido na C�mara: <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" class="name-lider"><?php the_title('<span">','</span>'); ?></a></p>
						</div>				   
				   
						<?php } } ?>
				</div> <!-- #flex-me -->
			    <?php else : ?>
				<div class="alert">
					<strong>Nenhum vereador encontrado.</strong>
				</div>
				<?php endif; ?>

				<?php wp_reset_query(); ?>
			
			</div>

		</div>

<?php get_footer(); ?>
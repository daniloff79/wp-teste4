<?php get_header(); ?>

<div class="main-content"> 

<?php if(have_posts()) { 
	the_post();
	the_content();
	} 
?>
	
</div> <!-- / .main-content -->

<?php get_footer(); ?>
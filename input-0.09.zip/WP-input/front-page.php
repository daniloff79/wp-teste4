<?php get_header(); ?>

<div class="main-content"> 
	<div class="container-fluid">
		<div class="carousel slide hidden-xs">    
			<div class="carousel-inner">
				<div class="item active">
				<img src="<?php echo get_template_directory_uri(); ?>/img/4196.jpg" alt="slide">	
				</div>
			</div>
		</div>
	</div>

	<div class="clearfix"></div>
	
		<?php if(have_posts()) { ?>

			<?php 
			the_post();
			the_content();
			?>
					
		<?php } ?>	
	
</div> <!-- / .main-content -->

<?php get_footer(); ?>
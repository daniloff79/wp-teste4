<!DOCTYPE html>
<html lang="pt-BR">
<head>

<title>Input</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="initial-scale=1, maximum-scale=1" />

<?php if (is_front_page()) { ?>
	<link href="<?php echo get_template_directory_uri(); ?>/home.css" rel="stylesheet" /> 
<?php } ?>
<link rel="icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon.ico">	

<?php wp_head(); ?>
</head>

<body <?php if(!is_search()) { body_class(isset($class) ? $class : ''); } else { ?>class="search search-results"<?php } ?>>

<div class="bg-black">
	<div class="container">
		<div class="row menu-acesso">
			<div class="col-sm-4 col-md-3 col-sm-offset-0 col-md-offset-3">
			  <span class="mail"><i class="glyphicon glyphicon-envelope"></i> <a href="mailto:input@input.com.vc">input@input.com.vc</a></span> &nbsp;
			  <span class="telefone"><i class="glyphicon glyphicon-earphone"></i> 11 3976 8000</span>
			</div>
			<div class="col-sm-4 col-md-3 hidden-xs">		
				<form role="search" method="get" class="input-group" action="/">
					<input type="search" class="form-control" placeholder="Busca" aria-describedby="search" value="" name="s" id="search">
					<div class="input-group-btn">
						<button class="btn btn-default" type="submit" id="search-button"><i class="glyphicon glyphicon-search"></i></button>
					</div>
				</form>
			</div>	
			<div class="col-sm-4 col-md-3">
				<div class="restrita-container">
					<i class="spritesheet logo-area-restrita"></i>
					<a href="http://www.input.com.vc/restrita"><span class="visible-md-inline visible-lg-inline">�rea </span>Restrita</a>
				</div>
				<ul class="idioma navbar-right">
				    <li class="dropdown">
				    </li>
				</ul>
			</div>
		</div>
	</div>
</div>

<div class="bg-black-op50">
	<div class="container">
		<div class="row menu-navegacao">
			<nav class="navbar navbar-default" role="navigation">
				<div class="col-sm-3 navbar-header">
					<div class="navbar-brand">
						<a href="/">
							 <img src="<?php echo get_template_directory_uri(); ?>/img/logo.png" class="img-responsive" alt="Input Tecnologia" />
						</a>
					</div>
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<div class="col-sm-offset-3">
					<div class="collapse navbar-collapse" id="menu1">
						<?php wp_nav_menu( array('menu' => 'Menu principal', 'menu_class' => 'nav navbar-nav',  'container'=> false)); ?>
				</div>
			</nav>
		</div>
	</div>
</div>

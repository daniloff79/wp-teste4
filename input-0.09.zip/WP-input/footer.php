
<div class="footer">
    <div class="container">
		<div class="row">
			<div class="col-sm-6 logo-copy">
				<img src="<?php echo get_template_directory_uri(); ?>/img/logo-rodape.png" />
				<div class="copyright">
				&copy; 2017 INPUT.<br class="hidden-md hidden-lg"> TODOS OS DIREITOS RESERVADOS.
				</div>
			</div>
			<div class="col-sm-2 redes-sociais">
				Redes Sociais:<br>
				<a href="https://www.facebook.com/inputcenter?fref=ts" target="_blank"><img class="spritesheet logo-social facebook" src="" ></a>
				<a href="https://www.linkedin.com/inputcenter" target="_blank"><img class="spritesheet logo-social linkedin" src="" ></a>
			</div>
			<div class="col-sm-4 apoio-parceria">
			  <div class="col-sm-7">
				Apoiamos:
				<hr>
				<a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-abrinq.png" alt="Logo Abrinq" class="img-responsive"></a>
				<a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/img/logo-amigos-aacd.png" alt="Logo Amigos AACD" class="img-responsive"></a>
			  </div>
			  <div class="col-sm-5">
				Somos:
				<hr>
				<img src="<?php echo get_template_directory_uri(); ?>/img/logo-microsoft-partner.png" alt="Logo Microsoft Partner" class="img-responsive">
			  </div>
			</div>
		</div>
    </div>
</div>

<script>jQuery("#menu-item-120 a").attr("target", "_blank"); </script>

<?php wp_footer(); ?>	
</body>
</html>

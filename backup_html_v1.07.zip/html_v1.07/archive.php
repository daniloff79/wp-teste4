<?php get_header(); ?>

		<div class="row" id="content">

			<div class="col-md-12 withbreadcrumb">

				<div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
				<?php if(function_exists('bcn_display'))
				{
					bcn_display();
				}?>
				</div>

				<?php
				    if(have_posts()) { 
						$classes = get_body_class(); ?>
						<div class="clearfix" style="height 25px"></div>
						<?php if (in_array('post-type-archive-tf_events',$classes)) {
							//echo WP_FullCalendar::calendar(	array('post_type' => 'tf_events', 'taxonomy' => 'post_tag') );
							
							$selecao = array ( $_SERVER['QUERY_STRING'] );
							if($selecao[0] == "tag=nil-ramos") { 	
								echo do_shortcode( '[fullcalendar tag="nil-ramos"]' );
							} else { echo do_shortcode( '[fullcalendar]' ); }
							} ?>
						
							<div class="col-md-12">
							<?php while ( have_posts() ) : the_post(); ?>
									<?php
									if ($post_type == 'tf_events' ){ 
									} else { ?>
										<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
											<a href="<?php the_permalink() ?>"><?php the_title('<h1 class="entry-title">','</h1>'); ?></a>						
											<?php the_excerpt(); ?>
										</div>									
									<?php } ?>
							<?php endwhile; ?>
							</div>
				<?php } else { ?>
				<div class="alert">
					<?php $post_type = get_post_type(get_the_ID());
					if ($post_type == 'tf_events' ){ ?>
					<strong>Nenhum evento encontrado</strong>
				  <?php } else { ?>
					<strong>P&aacute;gina n&atilde;o encontrada</strong>
				  <?php } ?>
				</div>
				<?php } ?>
			</div>
		</div>

<?php get_footer(); ?>

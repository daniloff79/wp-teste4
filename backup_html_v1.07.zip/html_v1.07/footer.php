﻿		<div class="row-fluid footer">
			<script src="<?php echo get_template_directory_uri(); ?>/library/bootstrap.js"></script>	
			<?php if( is_front_page() ) { ?>
			<script src="<?php echo get_template_directory_uri(); ?>/library/lightslider.js"></script>
				<div class="col-md-12 footer0">
				<h4 class="text-center gray6">Cadastre-se</h4>
				<p class="gray6">Informe o seu e-mail para receber notícias e novidades da Câmara de Vinhedo:</p>
				<?php echo do_shortcode( '[formidable id=6]' ) ?>
			</div>
			<?php } ?>
			<div class="col-md-12 hidden-sx hidden-sm footer1" id="sitemap"> 
				<?php if ( dynamic_sidebar('footer-map') ) : else : endif; ?>
			</div>
		</div>	
	</div> <!-- /#main-container -->
	<div id="subfooter">
		<div class="container">	
			<div class="row footer2">
				<div class="col-md-12">
					<p class="copyright">&copy; <span class="strong">2017 - Câmara Municipal de Vinhedo</span></p>
				</div>
				<div class="clearfix"></div>
				<div class="col-sd-6 col-md-5">
					<img src="<?php echo get_template_directory_uri(); ?>/images/ico-local.png" class="icon"><p>Av. Dois de Abril, 78 - Centro -<br class="visible-xxs" /> Vinhedo/SP - CEP 13280-000</p><br />
					<img src="<?php echo get_template_directory_uri(); ?>/images/ico-fone.png" class="icon"><p>(19) 3826-7700</p><br />
					<img src="<?php echo get_template_directory_uri(); ?>/images/ico-mail.png" class="icon"><p>imprensa@camaravinhedo.sp.gov.br</p>
				</div>
				<div class="col-sd-6 col-md-2">
					<img src="<?php echo get_template_directory_uri(); ?>/images/ico-chegar.png" class="icon"><p><a href="/localizacao">Como chegar</a></p>
				</div>
				<div class="col-sd-12 col-md-4">	
					<p class="hidden-xs">Número de visitas: 
					<?php echo do_shortcode( '[visitor_counter]' ) ?> 
					</p>					
				</div>
				<div class="col-md-1">
					<a href="http://www.input.com.vc" id="logo-input"><img src="<?php echo get_template_directory_uri(); ?>/images/logo-input.png" alt="Input Center Tecnologia"></a>
				</div>
			</div>
		</div>
	</div> <!-- /#subfooter -->	
	<?php if (has_tag('galeria')) { ?>
	<script>
		jQuery(document).ready(function() { console.log("Tempo até DOMready: ", Date.now()-timerStart); });
		jQuery(window).load(function() { console.log("Tempo pra tudo carregar: ", Date.now()-timerStart); });
	</script>
	<?php } 
	if (is_front_page()) { ?>
	<script>
		var timerStart = Date.now();
	</script>
	<?php }?>
	<script>
		jQuery(".masthead nav #menu-item-1341 a").attr("target", "_blank");  // portal dos sevidores
		jQuery(".masthead nav #menu-item-1638 a").attr("target", "_blank"); // boletim municipal
		jQuery("#carousel-2-item-177").attr("target", "_blank"); // boletim municipal
	</script>

<?php wp_footer(); ?>	
</body>
</html>
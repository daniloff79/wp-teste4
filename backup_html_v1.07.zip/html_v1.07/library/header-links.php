<?php
/* 
Theme Name: Vinhedo
Theme URI: http://www.input.com.br
*/

if ( $_POST['update_themeoptions'] == 'true' ) { themeoptions_update(); }

?>
<div class="wrap">
	<h2>Links sociais</h2>
		<form method="post" action="">
			<input type="hidden" name="update_themeoptions" value="true" />

			<br />
			<p>Links usados no topo da p&aacute;gina</p>
			<br />

			<p>http://www.facebook.com/pages/<input type="text" name="facebook_username" id="facebook_username" size="48" value="<?php echo get_option('mytheme_facebook_username'); ?>" /> <input type="checkbox" name="display_facebook" id="display_facebook" <?php echo get_option('mytheme_display_facebook'); ?> /></p> 
			
			<p>http://twitter.com/<input type="text" name="twitter_username" id="twitter_username" size="48" value="<?php echo get_option('mytheme_twitter_username'); ?>" /> <input type="checkbox" name="display_twitter" id="display_twitter" <?php echo get_option('mytheme_display_twitter'); ?> /></p> 

			<p>https://www.youtube.com/<input type="text" name="youtube_username" id="youtube_username" size="48" value="<?php echo get_option('mytheme_youtube_username'); ?>" /> <input type="checkbox" name="display_youtube" id="display_youtube" <?php echo get_option('mytheme_display_youtube'); ?> /></p> 
			
			<br />
			<p class="publishing-action">
			<input type="submit" name="save_menu" value="salvar" class="button button-primary button-large menu-save" />
			</p>
		</form>
</div>
<?php

function themeoptions_update()
{
	if ($_POST['display_facebook']=='on') { $display = 'checked'; } else { $display = ''; }
	update_option('mytheme_display_facebook', 	$display);
	update_option('mytheme_facebook_username', 	$_POST['facebook_username']);

	if ($_POST['display_youtube']=='on') { $display = 'checked'; } else { $display = ''; }
	update_option('mytheme_display_youtube', 	$display);
	update_option('mytheme_youtube_username', 	$_POST['youtube_username']);

	if ($_POST['display_twitter']=='on') { $display = 'checked'; } else { $display = ''; }
	update_option('mytheme_display_twitter', 	$display);
	update_option('mytheme_twitter_username', 	$_POST['twitter_username']);
}

?>
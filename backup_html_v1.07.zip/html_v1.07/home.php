<?php get_header(); ?>

		<div class="row" id="content">

			<div class="col-md-12 withbreadcrumb">

				<div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
				<?php if(function_exists('bcn_display'))
				{
					bcn_display();
				}?>
				</div>
				<h1>Not�cias</h1>
				<?php 
				$paged = 1;
				if ( get_query_var('paged') ) $paged = get_query_var('paged');
				if ( get_query_var('page') ) $paged = get_query_var('page');
				$args = array(
					'post_type' => 'post',
					'cat' => '-62,-63,-64',
					'posts_per_page' => '5', 
					'paged' => $paged,
				);
				$wp_query = new WP_Query( $args );
				
				if(have_posts()) { ?>
				   <?php while(have_posts()) : the_post(); ?>
					<div id="post-<?php the_ID(); ?>" <?php post_class('row'); ?>>
						<?php 
						if(!has_category(62) && !has_category(63)) {
							echo "<br /><div class='col-xs-6 col-sm-3 col-md-2'>";
							the_post_thumbnail( array(218,9999) );
							echo "</div>
								  <div class='col-sm-9 col-md-10'>
								  <p class='gray9'>";
							the_time('j \d\e F \d\e Y');
							echo "</p>";
							the_title('<a href="' . get_permalink() . '"><h2 class="entry-title">','</h2></a>'); 
							the_excerpt();
							echo "</div><br />";
						} else {
							the_title('<h2>','</h2>'); 	
							$anexo = get_post_meta( get_the_ID(), 'wpcf-pdf-anexo',true);
							$arqanexo = substr($anexo, strrpos($anexo, '/') + 1);
							echo "<div class='panel-body'><a href='";
							echo $anexo;	
							echo "'>";
							echo $arqanexo;
							echo "</a></div>";
						}
						?>
					</div>
			
				<?php endwhile; ?>
			</div>
			<div class="col-md-12 pagination-container">
				<?php
					// pagination 
					the_posts_pagination( array(
					'base' => '/noticias/%#%',
					'title' => ' ',
					'prev_text' => '&lt;',
					'next_text' => '&gt;',
					'separator' => '&brvbar;',
					'mid_size'  => 3, )
					);
				?>
			</div>
			<?php } else { ?>
			<div class="col-md-12">
				<div class="alert">
					  <strong>P&aacute;gina n&atilde;o encontrada</strong>
				</div>
			</div>
			</div>
			<?php } ?> 
			
		</div><!-- /#content -->

<?php get_footer(); ?>
<?php get_header(); ?>

		<div class="row" id="content">
		
			<div class="col-md-12">
				<br />
				<?php
					if (false !== strpos($_SERVER['REQUEST_URI'], 'as_sessoes')) {
						header('HTTP/1.1 301 Moved Permanently'); 
						header('Location: http://camaravinhedo.sp.gov.br/institucional/sessoes/');
						echo '<p>O site da C�mara Municipal de Vinhedo mudou. Redirecionando para nova p�gina.</p>
							<script>window.location.href = "http://camaravinhedo.sp.gov.br/institucional/sessoes/";</script>';
					} elseif (false !== strpos($_SERVER['REQUEST_URI'], 'tv_camara')) {
						header('HTTP/1.1 301 Moved Permanently'); 
						header('Location: http://camaravinhedo.sp.gov.br/tv-camara');
						echo '<p>O site da C�mara Municipal de Vinhedo mudou. Redirecionando para nova p�gina.</p>
							<script>window.location.href = "http://camaravinhedo.sp.gov.br/tv-camara";</script>';	
					} elseif (false !== strpos($_SERVER['QUERY_STRING'], 'Resultado=leis')) {
						header('HTTP/1.1 301 Moved Permanently'); 
						header('Location: http://camaravinhedo.sp.gov.br/atividades-legislativas');
						echo '<p>O site da C�mara Municipal de Vinhedo mudou. Redirecionando para nova p�gina.</p>
							<script>window.location.href = "http://camaravinhedo.sp.gov.br/atividades-legislativas";</script>';				
					} elseif (false !== strpos($_SERVER['REQUEST_URI'], 'noticias/Default.aspx')) {
						header('HTTP/1.1 301 Moved Permanently'); 
						header('Location: http://camaravinhedo.sp.gov.br/noticias');
						echo '<p>O site da C�mara Municipal de Vinhedo mudou. Redirecionando para nova p�gina.</p>
							<script>window.location.href = "http://camaravinhedo.sp.gov.br/noticias";</script>';				
					} 
				?>
				
				<div class="alert">
				  <h3><b>P&aacute;gina n&atilde;o encontrada. Tente utilizar a busca.</b></h3>
				</div>

			</div>

		</div>
<?php get_footer(); ?>
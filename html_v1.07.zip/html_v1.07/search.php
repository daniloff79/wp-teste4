﻿<?php get_header(); ?>

		<div class="row">
			<div class="col-md-12">

			<h1 class="gray6">Resultados para <span class="gray3"><?php echo get_search_query(); ?></span></h1>
			
				<?php if(have_posts()) { ?>
				   <?php while(have_posts()) : the_post(); ?>
					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>	 
						<?php the_title('<a href="' . get_permalink() . '"><h1>','</h1></a>'); ?> 		
						<?php the_excerpt(); ?>
					</article>

				   <?php endwhile; ?>

				<?php } else { ?>
				
				<div class="alert">
				  <strong>Nada foi encontrado. Tente com outros termos.</strong>
				</div>
				<?php } ?>
				
			</div>
		</div>

<?php get_footer(); ?>
<?php
/**
 * Perfil do vereador
 */
get_header(); ?>

		<div class="row" id="content">

			<div class="col-md-12 withbreadcrumb">

				<div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
				<?php if(function_exists('bcn_display')) {
					bcn_display();
				}
				$classes = get_body_class();
				if (in_array('vereador-nil-ramos',$classes)) {
					?> 
					<script>
						jQuery('#menu-item-30').removeClass('active');
					</script>
					<?php
				} ?>
				</div>
			
				<?php if(have_posts()) : ?>
				   <?php while(have_posts()) : the_post(); ?>
					<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						
						<div class="col-sd-4 col-md-3">
							<?php the_title('<h2>','</h2>'); ?>
							<br />
							<?php the_post_thumbnail('full'); ?>
							<p style="margin-top: 10px">
								<img src="<?php 
									$terms = get_the_terms( $post->ID, 'partido' );
									if ($terms) {
										$terms_name = array();
										foreach ( $terms as $term ) {
											$terms_name[] = $term->slug;
										}
										$sigla = $terms_name[0];
										echo get_template_directory_uri();
										echo "/images/partidos/";
										if(empty($sigla)) { echo "0"; } else { echo $sigla; }
										echo ".png";
									}?>" style="width: 40px">
									<?php the_title('<span class="gray6">','</span>')?>
									<br />
									<span class="presid gray9"><?php $metap = get_post_meta( $post->ID, 'wpcf-mandatos_presidencia', true ); echo $metap; ?></span> 
							</p>
						</div>
						<div class="col-sd-7 col-md-6">
							<p class="vereador-p1">
							<?php $meta1 = get_post_meta( $post->ID, 'wpcf-extra1', true ); 
							echo $meta1; ?>
							</p>						

							<p class="vereador-mail">
							<a href="mailto:<?php $meta1 = get_post_meta( $post->ID, 'wpcf-emailvereador', true ); 
							echo $meta1; ?>"><?php $meta1 = get_post_meta( $post->ID, 'wpcf-emailvereador', true ); 
							echo $meta1; ?></a>
							</p>

							<?php if (get_post_meta( $post->ID, 'wpcf-facebookvereador', true )) { ?><p class="vereador-facebook">
							<a href="<?php $meta1 = get_post_meta( $post->ID, 'wpcf-facebookvereador', true ); 
							echo $meta1; ?>" target="_blank"><?php $meta1 = get_post_meta( $post->ID, 'wpcf-facebookvereador', true ); 
							echo $meta1; ?></a>
							</p><?php } ?>
							
							<?php if (get_post_meta( $post->ID, 'wpcf-twittervereador', true )) { ?><p class="vereador-twitter">
							<a href="<?php $meta1 = get_post_meta( $post->ID, 'wpcf-twittervereador', true ); 
							echo $meta1; ?>" target="_blank"><?php $meta1 = get_post_meta( $post->ID, 'wpcf-twittervereador', true ); 
							echo $meta1; ?></a></p><?php } ?>
							
							<?php if (get_post_meta( $post->ID, 'wpcf-sitevereador', true )) { ?><p class="vereador-site">
							<a href="<?php $meta1 = get_post_meta( $post->ID, 'wpcf-sitevereador', true ); 
							echo $meta1; ?>" target="_blank"><?php $meta1 = get_post_meta( $post->ID, 'wpcf-sitevereador', true ); 
							echo $meta1; ?></a></p><?php } ?>
							
							<?php if (get_post_meta( $post->ID, 'wpcf-blogvereador', true )) { ?><p class="vereador-blog">
							<a href="<?php $meta1 = get_post_meta( $post->ID, 'wpcf-blogvereador', true ); 
							echo $meta1; ?>" target="_blank"><?php $meta1 = get_post_meta( $post->ID, 'wpcf-blogvereador', true ); 
							echo $meta1; ?></a></p><?php } ?>
							
							<?php if (get_post_meta( $post->ID, 'wpcf-instagramvereador', true )) { ?><p class="vereador-instagram">
							<a href="<?php $meta1 = get_post_meta( $post->ID, 'wpcf-instagramvereador', true ); 
							echo $meta1; ?>" target="_blank"><?php $meta1 = get_post_meta( $post->ID, 'wpcf-instagramvereador', true ); 
							echo $meta1; ?></a></p><?php } ?>
							
							<p class="vereador-p2">
							<p style="margint-top: 15px"><b>Mandatos:</b><br /> 
							<span class="gray6"><?php $meta1 = get_post_meta( $post->ID, 'wpcf-mandatos', true ); 
							echo $meta1; ?></span>
							</p>
							
							<p class="vereador-p2"><b>Votos recebidos:</b> 
							<span class="gray6"><?php $meta1 = get_post_meta( $post->ID, 'wpcf-votos', true ); 
							echo $meta1; ?><br /></span>
							</p><br />				
							<span class="gray6 text-justify"><?php the_content(); ?></span>
						</div>
						<div class="clearfix col-sd-1 col-md-2 hidden-lg"></div>
						<div class="col-sd-4 col-md-3">						
							<p class="vereador-p1">

							<?php $slug = get_post_field( 'post_name', get_post() ); 

							if (get_post_meta( $post->ID, 'wpcf-proposituras', true )) { ?>
								<a href="<?php $meta1 = get_post_meta( $post->ID, 'wpcf-proposituras', true );
								echo $meta1; ?>">
							<?php } else {
								?>
								<a href="
								<?php echo get_site_url();
								echo "/tag/"; 
								echo $slug;
								echo "/?proposituras";
								?>" target="_new">
							<?php } ?>
							<button class="btn btn-propoe" type="button">Proposituras</button></a>
							<a href="
							<?php echo get_site_url();
							echo "/tag/"; 
							echo $slug;
							?>">
							<button class="btn btn-news" type="button">Not&iacute;cias relacionadas</button></a>
							<a href="/contato/fale-com-<?php $terms = get_the_terms( $post->id, 'vereador' );
							$terms_slugs = array();
							foreach( $terms as $term ) {
								$terms_slugs[] = $term->slug; 
							}
							echo $slug; ?>"><button class="btn btn-fale" type="button">Fale com o(a) vereador(a)</button></a>
							
							<?php 
							$classes = get_body_class();
							if (in_array('vereador-nil-ramos',$classes)) { ?>
							<a href="
							<?php echo get_site_url();
							echo "/events/?tag=nil-ramos";
							?>">
							<button class="btn btn-agenda" type="button">Agenda do Presidente</button></a>
							<?php } ?>
							</p>
						</div>
					</div>

				   <?php endwhile; ?>

				<?php else : ?>
				<div class="alert">
					<strong>Nenhum vereador encontrado.</strong>
				</div>
				<?php endif; ?>
			</div>

		</div>

<?php get_footer(); ?>
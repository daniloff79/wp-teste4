<?php get_header(); ?>

		<div class="row" id="content">

			<div class="col-md-12 withbreadcrumb">

				<div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
				<?php if(function_exists('bcn_display'))
				{
					bcn_display();
				}?>
				</div>
			
				<?php 
				$category = basename($_SERVER['REQUEST_URI']);
				$args = array(
					'post_type' => 'post',
					'showposts' => '-1',
					'category_name' => $category,					
				);
				query_posts( $args );
				
				if(have_posts()) { ?>
				<h3>Conte�do na categoria <span class="red"><?php echo $category ?></span></h3>	
				<?php while(have_posts()) : the_post(); ?>
					<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						<?php 
						if(!has_category(62) && !has_category(63)) {
							the_title('<div class="col-md-12"><a href="' . get_permalink() . '"><h2>','</h2></a></div>'); 
							echo "<div class='col-sm-9 col-md-10'>";
							the_excerpt();
							echo "</div>
								<div class='col-md-2'>";
							the_post_thumbnail('thumbnail');
							echo "</div><hr class='nohr'>";
						} else {
							the_title('<a href="' . get_permalink() . '"><h2>','</h2></a>'); 	
							$anexo = get_post_meta( get_the_ID(), 'wpcf-pdf-anexo',true);
							$filetype = wp_check_filetype($anexo);
							if($filetype['ext'] == pdf) {
								$arqanexo = substr($anexo, strrpos($anexo, '/') + 1);
							} else { $arqanexo = $anexo; }
							echo "<div class='panel-body'>";
							echo "<a href='";
							echo $anexo;
							if($filetype['ext'] == pdf) {
								echo "' class='pdf'>";
							} else { echo "' class='link'>"; }
							echo $arqanexo;
							echo "</a></div>";
						}
						?>
					</div>

				   <?php endwhile; ?>

				<?php } else { ?>
				<div class="alert">
				  <strong>P&aacute;gina n&atilde;o encontrada</strong>
				</div>
				<?php } ?>
			</div>

		</div>

<?php get_footer(); ?>
﻿<?php get_header(); ?>

		<div class="row">
			<div class="col-md-12">
				<div id="carousel-1" class="carousel slide" data-ride="carousel">
					<?php echo do_shortcode( '[carousel-1]' ) ?> 				
				</div>
			</div>		
			<?php echo do_shortcode( '[3-posts]' ) ?>			
		</div>
		
		<div class="row hidden-xs">
			<div class="col-md-12 slide-container">
				<div id="carousel-2" class="carousel slide">				
					<?php echo do_shortcode( '[carousel-2]' ) ?> 							
				</div>
			</div>
		</div>	

		<div class="row" id="content">
				<?php if(have_posts()) : ?>
				   <?php while(have_posts()) : the_post(); ?>
					<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>						
						<?php the_content(); ?>
					</div>
				   <?php endwhile; ?>

				<?php else : ?>
				<div class="alert">
				  <strong>P&aacute;gina n&atilde;o encontrada</strong>
				</div>
				<?php endif; ?>
		</div>

    	<script>
	    	jQuery(document).ready(function() {
				var largura = jQuery( window ).width();
				if (largura >= 768) {
					jQuery("#carousel-2-inner").lightSlider({
								loop:true,
								item: 6,
						pager:false,
							});
				} else {
					jQuery("#carousel-2-inner").lightSlider({
								loop:true,
								item: 4,
						pager:false,
							});				
				}
				jQuery(document).scroll(function () {
					jQuery("#featured-container").each(function () {
						var imagePos = jQuery("#featured-container").offset().top;
						var imageHeight = jQuery(".featured").height();
						var topOfWindow = jQuery(window).scrollTop();
						try {
							var newsPos = jQuery('.last-news article .entry-content img.post-thumnail').offset().top;

							imagePos = imagePos - 150;
							newsPos = newsPos - 500;
							/* console.log (imagePos);
							console.log (newsPos); */
							
							if (imagePos < topOfWindow + imageHeight && imagePos + imageHeight > topOfWindow) {
								jQuery(".featured").addClass("moveup");
							}
							/* else {
								jQuery(".featured").removeClass("moveup");
							}*/
							}
							catch(err) {
								console.log('sem conteudo');
							}
					});
				});

			});
    	</script>

<?php get_footer(); ?>
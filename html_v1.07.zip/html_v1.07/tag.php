<?php get_header(); ?>

		<div class="row" id="content">
			<div class="col-md-12 withbreadcrumb">

				<div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
				<?php if(function_exists('bcn_display'))
				{
					bcn_display();
				}?>
				</div>
				<br />
				<?php 
				$propositura = basename($_SERVER['QUERY_STRING']);
				if( $propositura == proposituras) {
					$args = array(
						'tag' => get_queried_object()->slug,
						'posts_per_page' => -1,
						'tax_query' => array( 
							array(
								'taxonomy' => 'category',
								'field'    => 'slug',
								'terms'    => $propositura,
							),
						) 
					);
					query_posts( $args ); 
				} ?>

				<?php if(have_posts()) : ?>

					<?php $count_posts = wp_count_posts();
						$published_posts = $count_posts->publish;
					?>
				   <?php while(have_posts()) : the_post(); ?>
					<div id="post-<?php the_ID(); ?>" <?php post_class('row'); ?>>
						<?php 
						if(!has_category(62) && !has_category(63) && !has_category(64)) {
							echo "<div class='col-xs-6 col-sm-3 col-md-2'>";
							the_post_thumbnail( array(218,9999) );
							echo "</div>
								  <div class='col-sm-9 col-md-10'>
								  <p class='gray9'>";
							the_time('j \d\e F \d\e Y');
							echo "</p>";
							the_title('<a href="' . get_permalink() . '"><h2 class="entry-title">','</h2></a>'); 
							the_excerpt();
							echo "</div><hr>";
						}
						?>
					</div>
			
				<?php endwhile; ?>

				<?php else : ?>
				<div class="alert">
				  <strong>P&aacute;gina n&atilde;o encontrada</strong>
				</div>
				<?php endif; ?>
			</div>

		</div>

<?php get_footer(); ?>
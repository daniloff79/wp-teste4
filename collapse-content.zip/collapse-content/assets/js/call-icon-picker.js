function call_icon(){

jQuery('.icp').iconpicker({
			title: 'Font Awesome Iocns', // Popover title (optional) only if specified in the template
			selected: false, // use this value as the current item and ignore the original
			defaultValue: true, // use this value as the current item if input or element value is empty
			placement: 'bottomRight', // (has some issues with auto and CSS). auto, top, bottom, left, right
			showFooter: false,
			mustAccept:true,
			
			
		});
		
		}
		jQuery('.icp').iconpicker({
			title: 'Font Awesome Iocns', // Popover title (optional) only if specified in the template
			selected: false, // use this value as the current item and ignore the original
			defaultValue: true, // use this value as the current item if input or element value is empty
			placement: 'bottomRight', // (has some issues with auto and CSS). auto, top, bottom, left, right
			showFooter: false,
			mustAccept:false,
			
		});
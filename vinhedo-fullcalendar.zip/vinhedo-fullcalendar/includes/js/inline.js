var wpfc_loaded = false;
var wpfc_counts = {};
jQuery(document).ready( function($){	
	var fullcalendar_args = {
		timeFormat: WPFC.timeFormat,
		defaultView: WPFC.defaultView,
		weekends: WPFC.weekends,
		header: {
			left: WPFC.header.left, center: WPFC.header.center, right: WPFC.header.right
		},
		month: WPFC.month,
		year: WPFC.year,
		theme: WPFC.wpfc_theme,
		firstDay: WPFC.firstDay,
		editable: false,
		eventSources: [{
				url : WPFC.ajaxurl, data : WPFC.data, tag: WPFC.tag,
				content: WPFC.content, ignoreTimezone: true, allDayDefault: false
		}],
	    eventRender: function(event, element) {
			$(element).tooltip({title:event.post_id, container: "body", trigger: "click"});
			if( event.post_id > 0 && WPFC.wpfc_qtips == 1 ){
				var event_data = { action : 'wpfc_qtip_content', post_id : event.post_id, event_id:event.event_id };
				element.qtip({
					content:{
						text : ' ',
						ajax : {
							url : WPFC.ajaxurl, type : "POST", data : event_data
						}
					},
					position : {
						my: WPFC.wpfc_qtips_my, at: WPFC.wpfc_qtips_at
					}
				});
			}
	    },
		loading: function(bool) {
			if (bool) {
				$(this).parent().find('.wpfc-loading').show();
			}else {
				$(this).parent().find('.wpfc-loading').hide();
			}
		},
		viewRender: function(view, element) {
			if( !wpfc_loaded ){
				var container = $(element).parents('.wpfc-calendar-wrapper');
				container.find('.fc-toolbar').after(container.next('.wpfc-calendar-search').show());
				//catchall selectmenu handle
			    $.widget( "custom.wpfc_selectmenu", $.ui.selectmenu, {
			        _renderItem: function( ul, item ) {
			        	var li = $( "<li>", { html: item.label.replace(/#([a-zA-Z0-9]{3}[a-zA-Z0-9]{3}?) - /g, '<span class="wpfc-cat-icon" style="background-color:#$1"></span>') } );
			        	if ( item.disabled ) {
			        		li.addClass( "ui-state-disabled" );
			        	}
			        	return li.appendTo( ul );
			        }
			    });
			}
			wpfc_loaded = true;
	    }
	};
	if( WPFC.wpfc_locale ){
		$.extend(fullcalendar_args, WPFC.wpfc_locale);
	}
	$(document).trigger('wpfc_fullcalendar_args', [fullcalendar_args]);
	$('.wpfc-calendar').fullCalendar(fullcalendar_args);
	
	$('#calendario2').find('.wpfc-calendar').fullCalendar('changeView', 'basicWeek');
	$('#calendario2').find('.wpfc-calendar').fullCalendar('option', 'height', 60);
	$('#calendario2 .cal2dois').fullCalendar("incrementDate",{ weeks: 1 });
	$('#calendario2 .cal2tres').fullCalendar("incrementDate",{ weeks: 2 });
	$('#calendario2 .cal2quatro').fullCalendar("incrementDate",{ weeks: 3 });
	$('#calendario2 .cal2cinco').fullCalendar("incrementDate",{ weeks: 4 });
	$('#calendario2 .cal2seis').fullCalendar("incrementDate",{ weeks: 5 });
	
	setTimeout(function() {
		$( '#content' ).ajaxComplete(function() {
			$('#calendario1 .fc-bg').parentsUntil('.fc-day-grid').removeClass('hidden');
			$('#calendario2 .fc-time').parentsUntil('.fc-day-grid').removeClass('hidden');
			$('#calendario2 .fc-week').each(function() { $(this).css('height',''); });
		
			var getUrlParameter = function getUrlParameter(sParam) {
				var sPageURL = decodeURIComponent(window.location.search.substring(1)),
				sURLVariables = sPageURL.split('&'),
				sParameterName,
				i;
				for (i = 0; i < sURLVariables.length; i++) {
					sParameterName = sURLVariables[i].split('=');
					if (sParameterName[0] === sParam) {
						return sParameterName[1] === undefined ? true : sParameterName[1];
					}
				}
			};
			if(getUrlParameter('tag') == 'nil-ramos') { console.log("presidente") }
		
			$('#calendario1 .fc-event').each(function(){	
				var text = $(".fc-tag", this).text();
				$(".fc-tag", this).text(text.replace('[object Object]', 'nil-ramos'));
				if(getUrlParameter('tag') != 'nil-ramos') {

				} else { 
					if($(".fc-tag", this).text() != "nil-ramos") {
						$(".fc-tag", this).parent(".fc-content").parent(".fc-event").css({'background-color' : 'transparent','border-color' : 'transparent',});
					} else {
						$(".fc-tag", this).parent(".fc-content").parent(".fc-event").css({'background-color' : '#cc0d2f','border-color' : '#cc0d2f',});
					}
				} 
			});
			$('#calendario2 .fc-event').each(function(){	
				var text = $(".fc-tag", this).text();
				$(".fc-tag", this).text(text.replace('[object Object]', 'nil-ramos'));	// *aqui: elimina evento com tag, melhorar ?
				if(getUrlParameter('tag') != 'nil-ramos') {
					if($(".fc-tag", this).text() == "nil-ramos") {
						$(".fc-tag", this).parent(".fc-content").parent(".fc-event").parent(".fc-event-container").hide();
						$(".fc-tag", this).parentsUntil(".fc-event-container").remove();
					}
				} else { 
					if($(".fc-tag", this).text() != "nil-ramos") {
						$(".fc-tag", this).parent(".fc-content").parent(".fc-event").parent(".fc-event-container").hide();
						$(".fc-tag", this).parentsUntil(".fc-event-container").remove();
					}	
				} 			
			});
		})
	}, 200);

	$('#calendario1 .fc-prev-button').click(function(){
		$('#calendario2 .cal2um').fullCalendar("incrementDate",{ month: -1 });
		$('#calendario2 .cal2dois').fullCalendar("incrementDate",{ month: -1 });
		$('#calendario2 .cal2tres').fullCalendar("incrementDate",{ month: -1 });
		$('#calendario2 .cal2quatro').fullCalendar("incrementDate",{ month: -1 });
		$('#calendario2 .cal2cinco').fullCalendar("incrementDate",{ month: -1 });
		$('#calendario2 .cal2seis').fullCalendar("incrementDate",{ month: -1 });
	});	
	$('#calendario1 .fc-next-button').click(function(){
		$('#calendario2 .cal2um').fullCalendar("incrementDate",{ month: 1 });
		$('#calendario2 .cal2dois').fullCalendar("incrementDate",{ month: 1 });
		$('#calendario2 .cal2tres').fullCalendar("incrementDate",{ month: 1 });
		$('#calendario2 .cal2quatro').fullCalendar("incrementDate",{ month: 1 });
		$('#calendario2 .cal2cinco').fullCalendar("incrementDate",{ month: 1 });
		$('#calendario2 .cal2seis').fullCalendar("incrementDate",{ month: 1 });
	});
	
});
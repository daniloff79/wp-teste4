<?php get_header(); ?>
				  
<section>
                      
    <div id="container">
	
        <div class="container article">
			<?php if ( have_posts() ) : ?>

			<div class="row">
				<div class="col-sm-12">
					<ol class="breadcrumb">
						<li><a href="/" id="homelink">Home</a></li>
						<li class="active">Not�cias</li>
					</ol>
				</div>
			</div>
			
			<div class="row row1">			
				<?php while ( have_posts() ) : the_post(); ?>
					<div class="col-md-12">
						<a href="<?php the_permalink(); ?>" class="title-link"><?php the_title( '<h1 class="page-header">', '</h1>' ); ?></a>
						
						<?php if ( has_post_thumbnail() ) { ?>
						<div class="resultado-resumo">
							<?php the_excerpt(); ?>
						</div>
						<div class="resultado-img">
							<?php the_post_thumbnail('medium', array('class' => 'img-responsive')); ?>
						</div>
						<?php } else {
							the_excerpt();				
						} ?>
					</div>
				<?php endwhile; ?>
			</div>

			<?php else : ?>
			<div class="row">
				<br />
				<div class="col-sm-12" style="background: white; min-height: 200px">
				<h2>Nenhuma not�cia encontrada</h2>
				</div>
			</div>
			
			<?php endif; ?>
        </div><!-- /.container article -->
		
    </div>

</section>

<?php get_footer(); ?>
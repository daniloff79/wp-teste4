<footer class="footer">
      <div class="container">
		<div class="row">
			<div class="col-md-12">
				<p class="footer-brand"><img src="<?php echo get_template_directory_uri(); ?>/img/logo.png" alt="logo Fram Capital"></p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-3">
				<p><b>Endereço</b><br />
				Av. Pres. Juscelino Kubitschek, 1700<br />
				2º Andar, cj. 22 – CEP 04543-000<br />
				São Paulo/SP – Brasil
				</p>
				<p><b>Telefone</b><br />
				11 3513-3100
				</p>
				<p><b>Ouvidoria - DTVM</b><br />
				0800 770 3726
				</p>
				<p>2017 &copy FRAM Capital. Todos os direitos reservados.
				Design by Eólica</p>
			</div>
			<div class="col-md-8 col-md-offset-1">
				<p style="height: 45px">Anbima Anbima Cetip Banco Central</p>
				<p class="dizeres-legais">Fundos de investimento não contam com garantia do administrador, do gestor, de qualquer mecanismo de seguro ou fundo garantidor de créditos - FGC. A rentabilidade obtida no passado não representa garantia de rentabilidade futura. A rentabilidade divulgada não é líquida de impostos. Leia o prospecto, o formulário de informações complementares, lâmina de informações essenciais e o regulamento antes de investir. É recomendada a leitura cuidadosa do prospecto e regulamento do fundo de investimento pelo investidor ao aplicar seus recursos.</p>
				<p class="dizeres-legais">A FRAM Capital não comercializa nem distribui cotas de fundos de investimentos ou qualquer outro valor mobiliário. As informações contidas neste site têm caráter meramente informativo e não constituem, nem devem ser consideradas como: solicitação, oferta ou recomendação para compra ou venda de cotas de qualquer fundo de investimentos gerido pela FRAM Capital ou quaisquer outros valores mobiliários.</p>
			</div>
		</div>
      </div>
 </footer>
<?php wp_footer(); ?>	
</body>
</html>
<?php get_header(); ?>

<div class="jumbotron">
	<div class="container">
		<div class="row">
			<?php
				if (have_posts()) {
					the_post();
					the_content();
				}
			?>
		</div>
	</div>
</div>

<?php get_footer(); ?>
<?php get_header(); ?>

<div class="jumbotron">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1><?php the_title(); ?></h1>
			</div> <!-- submenu -->
		</div>
	</div>
</div>

<main>
	<div class="container">
		<div class="row">
			<?php
				if (have_posts()) {
					the_post();
					the_content();
				}
			?>
		</div>
	</div>	
</main>

<?php get_footer(); ?>